﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcular_Click(object sender, EventArgs e)
        {
            DateTime data1 = Convert.ToDateTime(dtp1.Text);
            DateTime data2 = Convert.ToDateTime(dtp2.Text);

            lbxDif.Items.Add(data2.Date.Subtract(data1.Date).ToString());
        }
    }
}
