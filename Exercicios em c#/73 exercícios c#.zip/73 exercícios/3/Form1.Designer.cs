﻿namespace _3
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dtp1 = new System.Windows.Forms.DateTimePicker();
            this.dtp2 = new System.Windows.Forms.DateTimePicker();
            this.calcular = new ns1.BunifuThinButton2();
            this.lbxDif = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // dtp1
            // 
            this.dtp1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp1.Location = new System.Drawing.Point(32, 22);
            this.dtp1.MaxDate = new System.DateTime(2020, 12, 31, 0, 0, 0, 0);
            this.dtp1.Name = "dtp1";
            this.dtp1.Size = new System.Drawing.Size(200, 20);
            this.dtp1.TabIndex = 0;
            // 
            // dtp2
            // 
            this.dtp2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp2.Location = new System.Drawing.Point(32, 74);
            this.dtp2.MaxDate = new System.DateTime(2020, 12, 31, 0, 0, 0, 0);
            this.dtp2.Name = "dtp2";
            this.dtp2.Size = new System.Drawing.Size(200, 20);
            this.dtp2.TabIndex = 1;
            // 
            // calcular
            // 
            this.calcular.ActiveBorderThickness = 1;
            this.calcular.ActiveCornerRadius = 20;
            this.calcular.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.calcular.ActiveForecolor = System.Drawing.Color.White;
            this.calcular.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.calcular.BackColor = System.Drawing.Color.White;
            this.calcular.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("calcular.BackgroundImage")));
            this.calcular.ButtonText = "Calcular a diferença";
            this.calcular.Cursor = System.Windows.Forms.Cursors.Hand;
            this.calcular.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calcular.ForeColor = System.Drawing.Color.SeaGreen;
            this.calcular.IdleBorderThickness = 1;
            this.calcular.IdleCornerRadius = 20;
            this.calcular.IdleFillColor = System.Drawing.Color.White;
            this.calcular.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.calcular.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.calcular.Location = new System.Drawing.Point(32, 114);
            this.calcular.Margin = new System.Windows.Forms.Padding(5);
            this.calcular.Name = "calcular";
            this.calcular.Size = new System.Drawing.Size(200, 41);
            this.calcular.TabIndex = 2;
            this.calcular.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.calcular.Click += new System.EventHandler(this.calcular_Click);
            // 
            // lbxDif
            // 
            this.lbxDif.FormattingEnabled = true;
            this.lbxDif.Location = new System.Drawing.Point(32, 163);
            this.lbxDif.Name = "lbxDif";
            this.lbxDif.Size = new System.Drawing.Size(200, 108);
            this.lbxDif.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(275, 305);
            this.Controls.Add(this.lbxDif);
            this.Controls.Add(this.calcular);
            this.Controls.Add(this.dtp2);
            this.Controls.Add(this.dtp1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp1;
        private System.Windows.Forms.DateTimePicker dtp2;
        private ns1.BunifuThinButton2 calcular;
        private System.Windows.Forms.ListBox lbxDif;
    }
}

