﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void ordenar(string[] num)
        {
            ListBox ls = new ListBox();

            string aux = "";

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                    if (int.Parse(num[j] + "") < int.Parse(num[j + 1] + ""))
                    {
                        aux = num[j] + "";
                        num[j] = num[j + 1];
                        num[j + 1] = aux;
                    }
            }
            
            ls.Items.Add(String.Format("{0} + {1} + {2} = {3}", num[0], num[1],num[2], txtNum.Text));

            for (int j = 0; j < ls.Items.Count; j++)
            {
                aux = ls.Items[j].ToString();

                if(!txtResult.Lines.Contains(aux))
                    txtResult.Text += aux + "\n";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int par1=0, par2=0, par3=0;

            int numero = int.Parse(txtNum.Text);

            txtResult.Text = "";

            for (int i = 1; i < numero; i++)
            {
                for (int j = 1; j < i; j++) {

                    if (i != 0 && j != 0)
                    {
                        par1 = numero - i;
                        par2 = i - j;
                        par3 = j;

                        if ((par1 + par2 + par3) == numero)
                        {
                            string aux = (par1 + " " + par2 + " " + par3);

                            ordenar(aux.Split(' '));

                        }
                    }

                    
                }

                

            }
        }

        private void txtNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }
    }
}
