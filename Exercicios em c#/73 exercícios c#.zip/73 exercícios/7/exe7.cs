﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _6
{
    public partial class exe7 : Form
    {
        public exe7()
        {
            InitializeComponent();
        }


        int vrf; string resultado;

        private void decompositando(int num)
        {
           
            int d = 0;

            for(int i=2; i<= num; i++) 
            {
                if (vrf == int.Parse(txtNum.Text))
                {
                    //Verifica se a multiplicaco dos fatores, é igual ao numero, e para o ciclo;
                    break;
                }

                if (num % i == 0)
                {
                    d = (num / i);

                    //verifica a multiplicacão dos fatores;
                    vrf = vrf * i;

                    resultado += i + " x ";

                    num = d;

                    if (num != 1) {
                        decompositando(num);
                        
                    }
                }

            }
                

        }
        private void Decompor_Click(object sender, EventArgs e)
        {
            

            if (txtNum.Text != "" && txtNum.Text != "0" && txtNum.Text != "1")
            {

                int num = int.Parse(txtNum.Text);

                vrf = 1;

                txtResult.Text = num + " = ";

                decompositando(num);

                txtResult.Text += resultado.Substring(0, resultado.Length - 2);

                resultado = "";
            }
            else
            {
                MessageBox.Show("Caixa não pode estar vazia ou \n número tem de ser diferente de  0 e 1");
            }
        }

        private void txtNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }
    }
}
