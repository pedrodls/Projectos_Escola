﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5
{
    public partial class frmCampo : Form
    {

        public frmCampo()
        {
            InitializeComponent();
        }

        private void frmCampo_Load(object sender, EventArgs e)
        {
        }

        //Este contador fará a contagem dos campos preenchidos, caso a conta der 9 então aconteceu um empate!

        bool empate = true;

        //Controla a jogada: O ou X;

        bool controlarJogadas = true;

        //Campos preenchidos
        private bool verificar_campos_preenchidos()
        {
            if (btn1.Text != "" && btn2.Text != "" && btn3.Text != "" && btn4.Text != "" && btn5.Text != "" && btn6.Text != "" && btn7.Text != "" && btn8.Text != "" && btn9.Text != "")
                return true;
            else
                return false;

        }

        //Empate?????????????????????????????????
        private void verificar_empate(bool verf)
        {

            if (empate == true && verf)
            {
                MessageBox.Show("Empate");

                foreach (object bt in Controls)
                    if (bt is Button)
                        (bt as Button).Enabled = false;

                lblJogadas.Text = "Jogadas";
            }
        }

        //Verificará se as colunas estiverem preenchidas com o mesmo valor: O ou X;
        private void verificar_colunas()
        {
            if (btn1.Text == "X" && btn4.Text == "X" && btn7.Text == "X")
            {
                MessageBox.Show("Jogador X ganhou");

                foreach (object bt in Controls)
                    if (bt is Button)
                        (bt as Button).Enabled = false;

                jogador1.Text = (int.Parse(jogador1.Text) + 1).ToString();

                lblJogadas.Text = "Jogadas";

                empate = false;
            }
            else
            {
                if (btn1.Text == "O" && btn4.Text == "O" && btn7.Text == "O")
                {
                    MessageBox.Show("Jogador O ganhou");

                    foreach (object bt in Controls)
                        if (bt is Button)
                            (bt as Button).Enabled = false;

                    jogador2.Text = (int.Parse(jogador2.Text) + 1).ToString();

                    lblJogadas.Text = "Jogadas";

                    empate = false;

                }
            }

            if (btn2.Text == "X" && btn5.Text == "X" && btn8.Text == "X")
            {
                MessageBox.Show("Jogador X ganhou");

                foreach (object bt in Controls)
                    if (bt is Button)
                        (bt as Button).Enabled = false;

                jogador1.Text = (int.Parse(jogador1.Text) + 1).ToString();

                lblJogadas.Text = "Jogadas";

                empate = false;

            }
            else
            {
                if (btn2.Text == "O" && btn5.Text == "O" && btn8.Text == "O")
                {
                    MessageBox.Show("Jogador O ganhou");

                    foreach (object bt in Controls)
                        if (bt is Button)
                            (bt as Button).Enabled = false;

                    jogador2.Text = (int.Parse(jogador2.Text) + 1).ToString();

                    lblJogadas.Text = "Jogadas";

                    empate = false;

                }
            }

            if (btn6.Text == "X" && btn3.Text == "X" && btn9.Text == "X")
            {
                MessageBox.Show("Jogador X ganhou");

                foreach (object bt in Controls)
                    if (bt is Button)
                        (bt as Button).Enabled = false;

                jogador1.Text = (int.Parse(jogador1.Text) + 1).ToString();

                lblJogadas.Text = "Jogadas";

                empate = false;

            }
            else
            {
                if (btn3.Text == "O" && btn6.Text == "O" && btn9.Text == "O")
                {
                    MessageBox.Show("Jogador O ganhou");

                    foreach (object bt in Controls)
                        if (bt is Button)
                            (bt as Button).Enabled = false;

                    jogador2.Text = (int.Parse(jogador2.Text) + 1).ToString();

                    lblJogadas.Text = "Jogadas";

                    empate = false;

                }
            }
        }

        //Verificará se as linhas estiverem preenchidas com o mesmo valor: O ou X;

        private void verificar_linhas()
        {
            if (btn1.Text == "X" && btn2.Text == "X" && btn3.Text == "X")
            {
                MessageBox.Show("Jogador X ganhou");

                foreach (object bt in Controls)
                    if (bt is Button)
                        (bt as Button).Enabled = false;

                jogador1.Text = (int.Parse(jogador1.Text) + 1).ToString();

                lblJogadas.Text = "Jogadas";

                empate = false;

            }
            else
            {
                if (btn1.Text == "O" && btn2.Text == "O" && btn3.Text == "O")
                {
                    MessageBox.Show("Jogador O ganhou");

                    foreach (object bt in Controls)
                        if (bt is Button)
                            (bt as Button).Enabled = false;

                    jogador2.Text = (int.Parse(jogador2.Text) + 1).ToString();

                    lblJogadas.Text = "Jogadas";

                    empate = false;

                }
            }

            if (btn4.Text == "X" && btn5.Text == "X" && btn6.Text == "X")
            {
                MessageBox.Show("Jogador X ganhou");

                foreach (object bt in Controls)
                    if (bt is Button)
                        (bt as Button).Enabled = false;

                jogador1.Text = (int.Parse(jogador1.Text) + 1).ToString();

                lblJogadas.Text = "Jogadas";

                empate = false;

            }
            else
            {
                if (btn4.Text == "O" && btn5.Text == "O" && btn6.Text == "O")
                {
                    MessageBox.Show("Jogador O ganhou");

                    foreach (object bt in Controls)
                        if (bt is Button)
                            (bt as Button).Enabled = false;

                    jogador2.Text = (int.Parse(jogador2.Text) + 1).ToString();

                    lblJogadas.Text = "Jogadas";

                    empate = false;

                }
            }

            if (btn7.Text == "X" && btn8.Text == "X" && btn9.Text == "X")
            {
                MessageBox.Show("Jogador X ganhou");

                foreach (object bt in Controls)
                    if (bt is Button)
                        (bt as Button).Enabled = false;

                jogador1.Text = (int.Parse(jogador1.Text) + 1).ToString();

                lblJogadas.Text = "Jogadas";

                empate = false;

            }
            else
            {
                if (btn7.Text == "O" && btn8.Text == "O" && btn9.Text == "O")
                {
                    MessageBox.Show("Jogador O ganhou");

                    foreach (object bt in Controls)
                        if (bt is Button)
                            (bt as Button).Enabled = false;

                    jogador2.Text = (int.Parse(jogador2.Text) + 1).ToString();

                    lblJogadas.Text = "Jogadas";

                    empate = false;

                }
            }

        }

        //Verificará se as diagonais estiverem preenchidas com o mesmo valor: O ou X;

        private void verificar_diagonais()
        {
            if (btn1.Text == "X" && btn5.Text == "X" && btn9.Text == "X")
            {
                MessageBox.Show("Jogador X ganhou");

                foreach (object bt in Controls)
                    if (bt is Button)
                        (bt as Button).Enabled = false;

                jogador1.Text = (int.Parse(jogador1.Text) + 1).ToString();

                lblJogadas.Text = "Jogadas";

                empate = false;

            }
            else
            {
                if (btn1.Text == "O" && btn5.Text == "O" && btn9.Text == "O")
                {
                    MessageBox.Show("Jogador O ganhou");

                    foreach (object bt in Controls)
                        if (bt is Button)
                            (bt as Button).Enabled = false;

                    jogador2.Text = (int.Parse(jogador2.Text) + 1).ToString();

                    lblJogadas.Text = "Jogadas";

                    empate = false;

                }
            }

            if (btn3.Text == "X" && btn5.Text == "X" && btn7.Text == "X")
            {
                MessageBox.Show("Jogador X ganhou");

                foreach (object bt in Controls)
                    if (bt is Button)
                        (bt as Button).Enabled = false;

                jogador1.Text = (int.Parse(jogador1.Text) + 1).ToString();

                lblJogadas.Text = "Jogadas";

                empate = false;

            }
            else
            {
                if (btn3.Text == "O" && btn5.Text == "O" && btn7.Text == "O")
                {
                    MessageBox.Show("Jogador O ganhou");

                    foreach (object bt in Controls)
                        if (bt is Button)
                            (bt as Button).Enabled = false;

                    jogador2.Text = (int.Parse(jogador2.Text) + 1).ToString();

                    lblJogadas.Text = "Jogadas";

                    empate = false;

                }
            }
        }

        //Sinalizar jogadas
        private void sinalizar_jogada_X()
        {
            lblJogadas.Text = "X Jogou!";
        }

        //Sinalizar jogadas
        private void sinalizar_jogada_O()
        {
            lblJogadas.Text = "O Jogou!";
        }

        //Reiniciar o Jogo;
        private void btnResetar_Click(object sender, EventArgs e)
        {
            foreach (object bt in Controls)
                if (bt is Button)
                {
                    (bt as Button).Text = "";

                    (bt as Button).Enabled = true;
                }


            lblJogadas.Text = "Jogadas";

            btnResetar.Text = "Resetar";

        }

        //Verifica em cada click se: O ou X ganhou, ou foram ao empate
        private void verifica(object sender, MouseEventArgs e)
        { 
            verificar_linhas();

            verificar_colunas();

            verificar_diagonais();

            bool verf = verificar_campos_preenchidos();

            verificar_empate(verf);


            btnResetar.Enabled = true;
            btnResetar.Text = "Resetar";
        }

        //Muda o texto do botão concernente à jogada

        private void trocarTexo(object sender, EventArgs e)
        {
            if (((Button)sender).Text == "")
            {
                if (((Button)sender).Text == "" && controlarJogadas == true)
                {
                    ((Button)sender).Text = "X";

                    controlarJogadas = false;

                    sinalizar_jogada_X();


                }
                else
                {
                    if (((Button)sender).Text == "" && controlarJogadas == false)
                        ((Button)sender).Text = "O";

                    controlarJogadas = true;

                    sinalizar_jogada_O();

                }
            }
        }
    }
}