﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] valores = new int[10];

        private void Form1_Load(object sender, EventArgs e)
        {
            Random aleatorio = new Random();

            int valor=0;

            for(int i=0; i< 10; i++)
            {
                valor = aleatorio.Next(0, 9);

                lbxLista.Items.Add(valor+"");

                valores[i] = valor;
            }


        }

       
        private void txtSoNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }

        private void txtSotxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }

        private void txtSoPar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;

            if (char.IsDigit(e.KeyChar))
                if (e.KeyChar % 2 != 0)
                    e.Handled=true;


        }

        private void txtSoVogais_KeyPress(object sender, KeyPressEventArgs e)
        {
            string vogais = "aeiou";

            if (!vogais.Contains(e.KeyChar))
                e.Handled = true;

        }

        private bool primo(int e)
        {
            int cont = 0;

            for (int i = 1; i <= e; i++)
                if (e % i == 0)
                    cont++;

            if (cont == 2)
                return true;
            else
                return false;
        }

        private void txtSoPrimos_KeyPress(object sender, KeyPressEventArgs e)
        {

            string vogais = "23567";

            if (!vogais.Contains(e.KeyChar))
                e.Handled = true;


        }

        private void txtSoValList_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;

            if (!lbxLista.Items.Contains(e.KeyChar+""))
                e.Handled = true;
        }
    }
}
