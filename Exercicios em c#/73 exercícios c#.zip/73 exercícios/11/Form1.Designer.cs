﻿namespace _11
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSoNum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSoVogais = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSotxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSoPrimos = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSoValList = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lbxLista = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSoPar = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtSoNum
            // 
            this.txtSoNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoNum.Location = new System.Drawing.Point(219, 138);
            this.txtSoNum.MaxLength = 32741;
            this.txtSoNum.Name = "txtSoNum";
            this.txtSoNum.Size = new System.Drawing.Size(215, 38);
            this.txtSoNum.TabIndex = 0;
            this.txtSoNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoNum_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Só Números:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 295);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Só vogais";
            // 
            // txtSoVogais
            // 
            this.txtSoVogais.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoVogais.Location = new System.Drawing.Point(219, 295);
            this.txtSoVogais.MaxLength = 32741;
            this.txtSoVogais.Name = "txtSoVogais";
            this.txtSoVogais.Size = new System.Drawing.Size(215, 38);
            this.txtSoVogais.TabIndex = 3;
            this.txtSoVogais.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoVogais_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Só Textos:";
            // 
            // txtSotxt
            // 
            this.txtSotxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSotxt.Location = new System.Drawing.Point(219, 191);
            this.txtSotxt.MaxLength = 32741;
            this.txtSotxt.Name = "txtSotxt";
            this.txtSotxt.Size = new System.Drawing.Size(215, 38);
            this.txtSotxt.TabIndex = 1;
            this.txtSotxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSotxt_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 349);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(200, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Só Números primos";
            // 
            // txtSoPrimos
            // 
            this.txtSoPrimos.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoPrimos.Location = new System.Drawing.Point(219, 349);
            this.txtSoPrimos.MaxLength = 32741;
            this.txtSoPrimos.Name = "txtSoPrimos";
            this.txtSoPrimos.Size = new System.Drawing.Size(215, 38);
            this.txtSoPrimos.TabIndex = 4;
            this.txtSoPrimos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoPrimos_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 402);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(189, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Só valores da lista";
            // 
            // txtSoValList
            // 
            this.txtSoValList.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoValList.Location = new System.Drawing.Point(219, 402);
            this.txtSoValList.MaxLength = 32741;
            this.txtSoValList.Name = "txtSoValList";
            this.txtSoValList.Size = new System.Drawing.Size(215, 38);
            this.txtSoValList.TabIndex = 5;
            this.txtSoValList.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoValList_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(16, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(190, 25);
            this.label6.TabIndex = 11;
            this.label6.Text = "Só Números pares";
            // 
            // lbxLista
            // 
            this.lbxLista.FormattingEnabled = true;
            this.lbxLista.Location = new System.Drawing.Point(219, 12);
            this.lbxLista.Name = "lbxLista";
            this.lbxLista.Size = new System.Drawing.Size(215, 95);
            this.lbxLista.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(16, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(160, 25);
            this.label7.TabIndex = 13;
            this.label7.Text = "Valores da lista";
            // 
            // txtSoPar
            // 
            this.txtSoPar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoPar.Location = new System.Drawing.Point(219, 242);
            this.txtSoPar.MaxLength = 32741;
            this.txtSoPar.Name = "txtSoPar";
            this.txtSoPar.Size = new System.Drawing.Size(215, 38);
            this.txtSoPar.TabIndex = 2;
            this.txtSoPar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoPar_KeyPress);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbxLista);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtSoPar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtSoValList);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSoPrimos);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSotxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSoVogais);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSoNum);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSoNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSoVogais;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSotxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSoPrimos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSoValList;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox lbxLista;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSoPar;
    }
}

