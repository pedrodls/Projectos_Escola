﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _26
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            ListBox lb = new ListBox();

            Label lbl = new Label();

            double soma = 0;

            base.OnPaint(e);

            Rectangle rect = new Rectangle(10,10,200,400);

            e.Graphics.FillRectangle(Brushes.Transparent, rect);

            rect.Inflate(-10, -10);

            string aux = "";

            for (int i=2; i<10000; i++)
            {
                aux += i;

                for (int j = 0; j <= aux.Length - 1; j++)
                {
                    double n = double.Parse(aux[j] + "");

                    soma += Math.Pow(n, aux.Length);
                    
                }

                if (soma + "" == aux)
                    lb.Items.Add(aux);
                

                soma = 0;
                aux = "";
            }

            lbl.Text = "Todos os números narcisistas entre 1 e 10.000 são: \n\n";

            for (int i = 0; i < lb.Items.Count; i++)
                lbl.Text += lb.Items[i] + " \n";

            Font ft = new Font(this.Font, FontStyle.Bold);

                e.Graphics.DrawString(lbl.Text, ft, Brushes.Black, rect);

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }

        private void verificar(string aux)
        {
            double soma = 0;

            for (int j = 0; j <= aux.Length - 1; j++)
            {
                double n = double.Parse(aux[j] + "");

                soma += Math.Pow(n, aux.Length);

            }

            if (soma + "" == aux)
                lblResultado.Text = $"{aux} é um número Narcista";
            else
                lblResultado.Text = $"{aux} não é um número Narcista";

        }
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            verificar(textBox1.Text);
        }
    }
}
