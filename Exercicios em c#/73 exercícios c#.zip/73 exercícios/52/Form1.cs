﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _52
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRet_Click(object sender, EventArgs e)
        {
            string[] frase = textBox1.Text.Split(' ');

            textBox1.Text = "";

            for (int i = 0; i < frase.Length; i++)
                textBox1.Text += frase[i];
        }
    }
}
