﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _60
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        string[] numero = {"zero", "um", "dois", "tres", "quatro", "cinco", "seis", "sete", "oito", "nove"};
        int cont = -1;
        private void btnRes_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void soletrar(int i)
        {
            timer1.Tick += timer1_Tick ;

            if (i < txt1.TextLength)
                lbxResultado.Items.Add(numero[int.Parse(txt1.Text[i] + "")]);
            else
                timer1.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            cont++;

            soletrar(cont);
        }

        private void txt1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }
    }
}
