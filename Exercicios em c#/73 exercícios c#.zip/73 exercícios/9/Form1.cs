﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _9
{
    public partial class CalculadoraClbx : Form
    {
        public CalculadoraClbx()
        {
            InitializeComponent();
        }

        private void txtNum1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }

        double soma, dividir, multi, sub, resultado;



        private void CalculadoraClbx_Load(object sender, EventArgs e)
        {   
        }

        private void chbx1_CheckedChanged(object sender, EventArgs e)
        {
            if (chbx1.Checked && txtNum1.Text != "" && txtNum2.Text != "")
            {
                soma = double.Parse(txtNum1.Text) + double.Parse(txtNum2.Text);

                resultado = soma;

                tempo.Enabled = true;
            }
        }

        private void chbx2_CheckedChanged(object sender, EventArgs e)
        {
           if(chbx2.Checked && txtNum1.Text != "" && txtNum2.Text != "")
            {
                sub = double.Parse(txtNum1.Text) - double.Parse(txtNum2.Text);

                resultado = sub;

                tempo.Enabled = true;

            }
        }

        private void chbx3_CheckedChanged(object sender, EventArgs e)
        {
            if(chbx3.Checked && txtNum1.Text !=""&& txtNum2.Text!="")
            {
                multi = double.Parse(txtNum1.Text) * double.Parse(txtNum2.Text);

                resultado = multi;

                tempo.Enabled = true;

            }
        }

        private void chbx4_CheckedChanged(object sender, EventArgs e)
        {
            if (chbx4.Checked && txtNum1.Text != "" && txtNum2.Text != "")
            {
                dividir = double.Parse(txtNum1.Text) / double.Parse(txtNum2.Text);

                resultado = dividir;

                tempo.Enabled = true;
            }
        }


        private void add()
        {
                lbxResultado.Items.Add(resultado);

                resultado = 0;

                tempo.Enabled = false;
        }



        private void tempo_Tick(object sender, EventArgs e)
        {
            add();
        }
    }
}
