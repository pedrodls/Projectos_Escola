﻿namespace _9
{
    partial class CalculadoraClbx
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chbx1 = new System.Windows.Forms.CheckBox();
            this.chbx2 = new System.Windows.Forms.CheckBox();
            this.chbx3 = new System.Windows.Forms.CheckBox();
            this.chbx4 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.lbxResultado = new System.Windows.Forms.ListBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tempo = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.chbx4);
            this.groupBox1.Controls.Add(this.chbx3);
            this.groupBox1.Controls.Add(this.chbx2);
            this.groupBox1.Controls.Add(this.chbx1);
            this.groupBox1.Location = new System.Drawing.Point(240, 71);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(123, 122);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // chbx1
            // 
            this.chbx1.AutoSize = true;
            this.chbx1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbx1.Location = new System.Drawing.Point(6, 19);
            this.chbx1.Name = "chbx1";
            this.chbx1.Size = new System.Drawing.Size(89, 29);
            this.chbx1.TabIndex = 2;
            this.chbx1.Text = "Somar";
            this.chbx1.UseVisualStyleBackColor = true;
            this.chbx1.CheckedChanged += new System.EventHandler(this.chbx1_CheckedChanged);
            // 
            // chbx2
            // 
            this.chbx2.AutoSize = true;
            this.chbx2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbx2.Location = new System.Drawing.Point(6, 43);
            this.chbx2.Name = "chbx2";
            this.chbx2.Size = new System.Drawing.Size(99, 29);
            this.chbx2.TabIndex = 3;
            this.chbx2.Text = "Subtrair";
            this.chbx2.UseVisualStyleBackColor = true;
            this.chbx2.CheckedChanged += new System.EventHandler(this.chbx2_CheckedChanged);
            // 
            // chbx3
            // 
            this.chbx3.AutoSize = true;
            this.chbx3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbx3.Location = new System.Drawing.Point(6, 68);
            this.chbx3.Name = "chbx3";
            this.chbx3.Size = new System.Drawing.Size(118, 29);
            this.chbx3.TabIndex = 4;
            this.chbx3.Text = "Multiplicar";
            this.chbx3.UseVisualStyleBackColor = true;
            this.chbx3.CheckedChanged += new System.EventHandler(this.chbx3_CheckedChanged);
            // 
            // chbx4
            // 
            this.chbx4.AutoSize = true;
            this.chbx4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbx4.Location = new System.Drawing.Point(6, 91);
            this.chbx4.Name = "chbx4";
            this.chbx4.Size = new System.Drawing.Size(84, 29);
            this.chbx4.TabIndex = 5;
            this.chbx4.Text = "Dividir";
            this.chbx4.UseVisualStyleBackColor = true;
            this.chbx4.CheckedChanged += new System.EventHandler(this.chbx4_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 280);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 31);
            this.label1.TabIndex = 100;
            this.label1.Text = "Resultados:";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(113, 114);
            this.txtNum1.MaxLength = 10;
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(100, 20);
            this.txtNum1.TabIndex = 0;
            this.txtNum1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNum1_KeyPress);
            // 
            // lbxResultado
            // 
            this.lbxResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxResultado.FormattingEnabled = true;
            this.lbxResultado.ItemHeight = 31;
            this.lbxResultado.Location = new System.Drawing.Point(240, 224);
            this.lbxResultado.Name = "lbxResultado";
            this.lbxResultado.Size = new System.Drawing.Size(120, 159);
            this.lbxResultado.TabIndex = 6;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(113, 196);
            this.txtNum2.MaxLength = 10;
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(100, 20);
            this.txtNum2.TabIndex = 2;
            this.txtNum2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNum1_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(33, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Insira o 1º  número:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(33, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Insira o 2º  número:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(246, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Operações";
            // 
            // tempo
            // 
            this.tempo.Interval = 4000;
            this.tempo.Tick += new System.EventHandler(this.tempo_Tick);
            // 
            // CalculadoraClbx
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 415);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.lbxResultado);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "CalculadoraClbx";
            this.ShowIcon = false;
            this.Text = "Calculadora com checkList";
            this.Load += new System.EventHandler(this.CalculadoraClbx_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chbx4;
        private System.Windows.Forms.CheckBox chbx3;
        private System.Windows.Forms.CheckBox chbx2;
        private System.Windows.Forms.CheckBox chbx1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.ListBox lbxResultado;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer tempo;
    }
}

