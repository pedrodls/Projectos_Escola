﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _46
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtFrase_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (txtNome.TextLength > 0)
                if (txtNome.Text[txtNome.TextLength - 1] == ' ')
                    e.KeyChar = ch.ToString().ToUpper()[0];

            if(txtNome.TextLength==0)
                e.KeyChar = ch.ToString().ToUpper()[0];

        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            string[] nome = txtNome.Text.Split(' ');

            for (int i = 0; i < nome.Length; i++)
                txtRes.Text += nome[i].Substring(0, 1) +" ";
        }
    }
}
