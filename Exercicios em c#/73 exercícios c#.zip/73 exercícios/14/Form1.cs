﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int numPrincipal = 0, num1 = 0, num2 = 0, x=0, y=0;

        private string calcular()
        {
            string resultado = "";

            if (num1 > numPrincipal)
                x = num1 - numPrincipal;
            else
                x = numPrincipal - num1;

            if (num2 > numPrincipal)
                y = num2 - numPrincipal;
            else
                y = numPrincipal - num2;

            if (x > y)
                resultado = (num2 + " mais proximo de "+numPrincipal);
            else
                resultado = (num1 + " mais proximo de " + numPrincipal);

            if(x == y)
                resultado = ("Ambos estão próximos de "+ numPrincipal);

            return resultado;
        }

        private void inserir_valor(int index)
        {
            try
            {
                if (index == 1)
                {
                    numPrincipal = int.Parse(txt1.Text);
                    num1 = int.Parse(txt2.Text);
                    num2 = int.Parse(txt3.Text);

                }

                if (index == 2)
                {
                    numPrincipal = int.Parse(txt2.Text);
                    num1 = int.Parse(txt1.Text);
                    num2 = int.Parse(txt3.Text);

                }

                if (index == 3)
                {
                    numPrincipal = int.Parse(txt3.Text);
                    num1 = int.Parse(txt1.Text);
                    num2 = int.Parse(txt2.Text);

                }

                txtResult.Text = calcular();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro Verifica bem todos os campos numéricos Introduzidos!! \n\n\n" + ex.ToString());
            }


            

        }

        private void txt1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar=='-'))
                e.Handled = true;
        }

        private void btnTransferir_Click(object sender, EventArgs e)
        {
            if (!(txt1.Text != "" && txt2.Text != "" && txt3.Text != ""))
                MessageBox.Show("Preencha todos campos");
            else
            {
                MessageBox.Show("Transferidos com sucesso");

                cmb.Items.Clear();
                cmb.Items.Add("1) " + txt1.Text);
                cmb.Items.Add("2) " + txt2.Text);
                cmb.Items.Add("3) " + txt3.Text);
               
            }
           
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Limpados com sucesso");

            txt1.Text = ""; txt2.Text = ""; txt3.Text = "";
            
            cmb.Items.Clear();
            
        }

        private void cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            string numero = cmb.SelectedItem.ToString();

           inserir_valor(int.Parse(numero[0]+""));
        }
    }
}
