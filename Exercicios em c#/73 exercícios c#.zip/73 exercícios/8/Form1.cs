﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _8
{
    public partial class frmRelogioDigital : Form
    {
        public frmRelogioDigital()
        {
            InitializeComponent();
        }



       
        private string[] imagens = new string[10];
        private string hora = "", minuto = "", segundo = "";


        private void carregar_imagem()
        {
            for (int i = 0; i < 10; i++)
                imagens[i] = @"C:\Users\Pedro Sousa\Desktop\Escola\TLP\c#\73 exercícios\8\" + i + ".png";
        }

        private void colocarImagem(int indice, PictureBox pbx)
        {
            pbx.Image = Image.FromFile(imagens[indice]);
        }

        private void actualizarHora()
        {
            colocarImagem(int.Parse(hora[0].ToString()), pbx1);
            colocarImagem(int.Parse(hora[1].ToString()), pbx2);

            colocarImagem(int.Parse(minuto[0].ToString()), pbx3);
            colocarImagem(int.Parse(minuto[1].ToString()), pbx4);

            colocarImagem(int.Parse(segundo[0].ToString()), pbx5);
            colocarImagem(int.Parse(segundo[1].ToString()), pbx6);
        }

        private void hora_minuto_segundo()
        {
            if (DateTime.Now.Hour.ToString().Length == 1)
                hora = "0" + DateTime.Now.Hour.ToString();
            else
                hora = DateTime.Now.Hour.ToString();

            if (DateTime.Now.Minute.ToString().Length == 1)
                minuto = "0" + DateTime.Now.Minute.ToString();
            else
                minuto = DateTime.Now.Minute.ToString();

            if (DateTime.Now.Second.ToString().Length == 1)
                segundo = "0" + DateTime.Now.Second.ToString();
            else
                segundo = DateTime.Now.Second.ToString();
        }
      
        private void iniciar()
        {
            hora_minuto_segundo();

            actualizarHora();
        }

        private void tempo_Tick(object sender, EventArgs e)
        {
            iniciar();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            lblData.Text = DateTime.Now.ToString("dd/MM/yyyy");

            carregar_imagem();

            tempo.Tick += new EventHandler(tempo_Tick);

            

          
        }
    }
}
