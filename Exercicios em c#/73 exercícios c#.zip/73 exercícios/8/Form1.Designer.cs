﻿namespace _8
{
    partial class frmRelogioDigital
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblData = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pbx4 = new System.Windows.Forms.PictureBox();
            this.pbx6 = new System.Windows.Forms.PictureBox();
            this.pbx5 = new System.Windows.Forms.PictureBox();
            this.pbx3 = new System.Windows.Forms.PictureBox();
            this.pbx2 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pbx1 = new System.Windows.Forms.PictureBox();
            this.tempo = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.BackColor = System.Drawing.Color.Black;
            this.lblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.ForeColor = System.Drawing.Color.Yellow;
            this.lblData.Location = new System.Drawing.Point(114, 113);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(147, 29);
            this.lblData.TabIndex = 0;
            this.lblData.Text = "dd/mm/aaaa";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::_8.Properties.Resources.ponto;
            this.pictureBox9.Location = new System.Drawing.Point(219, 37);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(22, 50);
            this.pictureBox9.TabIndex = 9;
            this.pictureBox9.TabStop = false;
            // 
            // pbx4
            // 
            this.pbx4.Location = new System.Drawing.Point(177, 37);
            this.pbx4.Name = "pbx4";
            this.pbx4.Size = new System.Drawing.Size(22, 50);
            this.pbx4.TabIndex = 8;
            this.pbx4.TabStop = false;
            // 
            // pbx6
            // 
            this.pbx6.Location = new System.Drawing.Point(289, 37);
            this.pbx6.Name = "pbx6";
            this.pbx6.Size = new System.Drawing.Size(22, 50);
            this.pbx6.TabIndex = 7;
            this.pbx6.TabStop = false;
            // 
            // pbx5
            // 
            this.pbx5.Location = new System.Drawing.Point(261, 37);
            this.pbx5.Name = "pbx5";
            this.pbx5.Size = new System.Drawing.Size(22, 50);
            this.pbx5.TabIndex = 6;
            this.pbx5.TabStop = false;
            // 
            // pbx3
            // 
            this.pbx3.Location = new System.Drawing.Point(151, 37);
            this.pbx3.Name = "pbx3";
            this.pbx3.Size = new System.Drawing.Size(22, 50);
            this.pbx3.TabIndex = 4;
            this.pbx3.TabStop = false;
            // 
            // pbx2
            // 
            this.pbx2.Location = new System.Drawing.Point(73, 37);
            this.pbx2.Name = "pbx2";
            this.pbx2.Size = new System.Drawing.Size(22, 50);
            this.pbx2.TabIndex = 3;
            this.pbx2.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::_8.Properties.Resources.ponto;
            this.pictureBox2.Location = new System.Drawing.Point(113, 37);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(22, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pbx1
            // 
            this.pbx1.Location = new System.Drawing.Point(45, 37);
            this.pbx1.Name = "pbx1";
            this.pbx1.Size = new System.Drawing.Size(22, 50);
            this.pbx1.TabIndex = 1;
            this.pbx1.TabStop = false;
            // 
            // tempo
            // 
            this.tempo.Enabled = true;
            this.tempo.Interval = 1;
            this.tempo.Tick += new System.EventHandler(this.tempo_Tick);
            // 
            // frmRelogioDigital
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(358, 149);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pbx4);
            this.Controls.Add(this.pbx6);
            this.Controls.Add(this.pbx5);
            this.Controls.Add(this.pbx3);
            this.Controls.Add(this.pbx2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pbx1);
            this.Controls.Add(this.lblData);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmRelogioDigital";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Relógio  Digital";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.PictureBox pbx1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pbx2;
        private System.Windows.Forms.PictureBox pbx3;
        private System.Windows.Forms.PictureBox pbx5;
        private System.Windows.Forms.PictureBox pbx6;
        private System.Windows.Forms.PictureBox pbx4;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Timer tempo;
    }
}

