﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _33
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            if (txtFrase.TextLength != 0 && txtPalavra.TextLength != 0)
            {
                string[] frase = txtFrase.Text.Split(' ');

                if (frase.Contains(txtPalavra.Text))
                {
                    for (int i = 0; i < frase.Length; i++)
                    {
                        if (frase[i] == txtPalavra.Text)
                            frase[i]="ESCOLA";
                    }

                    txtResult.Text = "";

                    for (int i = 0; i < frase.Length; i++)
                        txtResult.Text += frase[i]+" ";

                }
                else
                    MessageBox.Show("Palavra não encontrada!");

            }
            else
                MessageBox.Show("Preencha todos os campos!");
            
        }
    }
}
