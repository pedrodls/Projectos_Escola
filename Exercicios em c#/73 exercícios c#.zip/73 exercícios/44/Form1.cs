﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _44
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnContar_Click(object sender, EventArgs e)
        {
            int cont = 0; string[] vetCont = new string[txtFrase.TextLength];

                for (int i = 0; i < txtFrase.TextLength; i++)
                {

                    for (int j = 0; j < txtFrase.TextLength; j++)
                        if (txtFrase.Text[i] == txtFrase.Text[j])
                            cont++;

                    vetCont[i] = $"'{txtFrase.Text[i]}' está repetido {cont} vezes";

                    cont = 0;
                }

            for (int i = 0; i < txtFrase.TextLength; i++)
                if(!txtResult.Text.Contains(vetCont[i]))
                    txtResult.Text += vetCont[i] + "\n";
        }
    }
}
