﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _49
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        


        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" Bengo-BE \n Benguela-BG \n Bié-BI \n Cabinda-CB \n Cuando Cubango-CC \n Cuanza Sul-CS \n Cuanza-Norte-CN \n Cunene-CU \n Huambo-HB \n Huíla-HL \n Luanda-LD \n Lunda Norte-LN \n Lunda Sul-LS \n Malanje-ML \n Moxico-MX \n Namibe-NM \n Uíge-UE \n Zaire-ZE");
                                
        }

        private void btnSeg_Click(object sender, EventArgs e)
        {
            string[] matricula = textBox1.Text.Split('-');

            var provincias = new Dictionary<string, string>(){
                {"BE", "Bengo"},{"BG", "Benguela"},{"BI","Bié"},{"CB", "Cabinda" },{"CC", "Cuando Cubango"},{"CS", "Cuanza Sul" },{"CN","Cuanza Norte"},{ "CU","Cunene"},{"HB","Huambo"},{"HL","Huíla"},{"LD","Luanda"},{"LN","Lunda Norte" },{"LS", "Lunda Sul"},{"ML","Malanje" },{"MX","Moxico" },{"UE", "Uíge"},{"ZE","Zaire"}
            };

            if (!(new Regex(@"^\b[A-Z][A-Z] [0-9][0-9]-[0-9][0-9]-[A-Z][A-Z]")).IsMatch(textBox1.Text))
                MessageBox.Show("Formato da matrícula Incorrecta! \nConsulte as síglas e tente novamente!!!");
            else
            {
                try {

                    int sucessor1 = (int)matricula[2].ToCharArray()[0];
                    int sucessor2 = (int)matricula[2].ToCharArray()[1];

                    if (sucessor1 == (int)'Z')
                    {
                        sucessor1 = (int)'A';
                        sucessor2++;
                    }
                    else
                        sucessor1++;

                    if (sucessor2 == (int)'Z')
                        sucessor2 = (int)'A';
                   

                    txtResult.Text = $"Matrícula da província de: ' {provincias[matricula[0].Substring(0, 2)]} '\n ";
                    txtResult.Text += "Matrícula sucessora: "+ (char)(sucessor1)+""+(char)(sucessor2);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Sigla Errada",$"{ex.Message}",MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = e.KeyChar.ToString().ToUpper()[0];
        }
    }
}
