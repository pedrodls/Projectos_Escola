﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _29
{
    public partial class Form1 : Form
    {
        List<int> listPar = new List<int>();
        List<int> listImpar = new List<int>();
        int cont = 0;


        public Form1()
        {
            InitializeComponent();
        }


        private void txtNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            lbxValores.Items.Clear();

            try
            {

                if (int.Parse(txtNum.Text) % 2 == 0)
                    listPar.Add(int.Parse(txtNum.Text));
                else
                    listImpar.Add(int.Parse(txtNum.Text));

                listPar.Sort();
                listImpar.Sort();

                for (int i = 0; i < listPar.Count; i++)
                    lbxValores.Items.Add(listPar[i]);

                for (int i = 0; i < listImpar.Count; i++)
                    lbxValores.Items.Add(listImpar[i]);

                cont++;

                if (cont == 11)
                {
                    lblControlo.Text = "Vetor Cheio";
                    btnInserir.Enabled = false;
                }
            }
            catch(Exception ex) { MessageBox.Show("Erro, Verifique os campos", $"{ex.Message}", MessageBoxButtons.OK, MessageBoxIcon.Error); }

        }
    }
}
