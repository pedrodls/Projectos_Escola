﻿namespace _29
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNum = new System.Windows.Forms.TextBox();
            this.btnInserir = new System.Windows.Forms.Button();
            this.lbxValores = new System.Windows.Forms.ListBox();
            this.lblControlo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtNum
            // 
            this.txtNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum.Location = new System.Drawing.Point(22, 52);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(252, 30);
            this.txtNum.TabIndex = 0;
            this.txtNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNum_KeyPress);
            // 
            // btnInserir
            // 
            this.btnInserir.Location = new System.Drawing.Point(199, 88);
            this.btnInserir.Name = "btnInserir";
            this.btnInserir.Size = new System.Drawing.Size(75, 23);
            this.btnInserir.TabIndex = 1;
            this.btnInserir.Text = "Inserir";
            this.btnInserir.UseVisualStyleBackColor = true;
            this.btnInserir.Click += new System.EventHandler(this.btnInserir_Click);
            // 
            // lbxValores
            // 
            this.lbxValores.FormattingEnabled = true;
            this.lbxValores.Location = new System.Drawing.Point(19, 173);
            this.lbxValores.Name = "lbxValores";
            this.lbxValores.Size = new System.Drawing.Size(261, 251);
            this.lbxValores.TabIndex = 2;
            // 
            // lblControlo
            // 
            this.lblControlo.AutoSize = true;
            this.lblControlo.ForeColor = System.Drawing.Color.Red;
            this.lblControlo.Location = new System.Drawing.Point(19, 128);
            this.lblControlo.Name = "lblControlo";
            this.lblControlo.Size = new System.Drawing.Size(0, 13);
            this.lblControlo.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(299, 450);
            this.Controls.Add(this.lblControlo);
            this.Controls.Add(this.lbxValores);
            this.Controls.Add(this.btnInserir);
            this.Controls.Add(this.txtNum);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "Trabalhando com vetores";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Button btnInserir;
        private System.Windows.Forms.ListBox lbxValores;
        private System.Windows.Forms.Label lblControlo;
    }
}

