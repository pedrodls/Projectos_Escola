﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _42
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void acabarFrase(string aux)
        {

        }
        private void btnResultado_Click(object sender, EventArgs e)
        {
            string[] frase1 = textBox1.Text.Split(' ');

            string[] frase2 = textBox2.Text.Split(' ');
            
            int cont = 0;

            string aux = "";
            
            if(frase1.Length == frase2.Length)
            {
                for (int i = 0; i < frase1.Length; i++)
                    aux += frase1[i] + " " + frase2[i] + " ";

                txtResult.Text = aux;
            }

            if (frase1.Length > frase2.Length) {

                for (int i = 0; i < frase1.Length; i++)
                {
                    txtResult.Text += frase1[i] + " " + frase2[i] + " ";

                    cont++;

                    if (cont == frase2.Length)
                    {
                        for (int j = i + 1; j < frase1.Length; j++)
                            txtResult.Text += frase1[j]+" ";

                        break;

                    }
                }

               
              
            }

            if (frase2.Length > frase1.Length)
            {
                for (int i = 0; i < frase2.Length; i++)
                {
                    txtResult.Text += frase1[i] + " " + frase2[i] + " ";

                    cont++;

                    if (cont == frase1.Length)
                    {
                        for (int j = i+1; j < frase2.Length; j++)
                            txtResult.Text += frase2[j] + " ";

                        break;
                    }
                }


            }

        }
    }
}
