﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _56
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string removerAcentuacao(string text)
        {
            return new string(text
                .Normalize(NormalizationForm.FormD)
                .Where(ch => char.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark)
                .ToArray());
        }

        private string ordenarString(string[] palavra)
        {
            string pal = "";

            IEnumerable<string> cadeia = from ch in palavra
                                         orderby ch.Substring(0,1)
                                         select ch;

            foreach(string str in cadeia)
                    pal+=str;

            return pal;
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            string[] palavra1 = new string[txt1.TextLength];
            string[] palavra2 = new string[txt2.TextLength];

            try
            {
                for (int i = 0; i < txt1.TextLength; i++)
                    palavra1[i] = removerAcentuacao(txt1.Text[i] + "").ToLower() + " ";

                for (int i = 0; i < txt1.TextLength; i++)
                    palavra2[i] = removerAcentuacao(txt2.Text[i] + "").ToLower() + " ";

                if (ordenarString(palavra1) == ordenarString(palavra2))
                    lblRes.Text = "As palavras são ANAGRAMAS";
                else
                    lblRes.Text = "As palavras Não são ANAGRAMAS";
            }
            catch
            {
                lblRes.Text = "As palavras Não são ANAGRAMAS";
            }


        }
    }
}
