﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _66
{
    public partial class Form1 : Form
    {
        int contE = 0, contL = 0, contN = 0;

        private void btnRes_Click(object sender, EventArgs e)
        {
            rbxRes.Text = "";

            rbxRes.Text = $"A frase tem {contN} numeros, {contL} letras e {contE} espaços!";

            contN = 0; contL = 0; contE = 0;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txt1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                contN++;

            if (char.IsWhiteSpace(e.KeyChar))
                contE++;

            if (char.IsLetter(e.KeyChar))
                contL++;
        }
    }
}
