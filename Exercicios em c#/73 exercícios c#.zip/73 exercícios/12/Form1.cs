﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        ListBox nomes = new ListBox();
        ListBox listCont = new ListBox();

        private void verificar()
        {
            int maior = 0, menor = 0; string nomeMaior = "", nomeMenor = "";

            for (int i = 0; i < listCont.Items.Count; i++)
            {
                if (i == 0)
                {
                    menor = int.Parse(listCont.Items[i].ToString());
                    nomeMenor = nomes.Items[i].ToString();
                }
                else if (int.Parse(listCont.Items[i].ToString()) < menor)
                {
                    menor = int.Parse(listCont.Items[i].ToString());
                    nomeMenor = nomes.Items[i].ToString();

                }


                if (int.Parse(listCont.Items[i].ToString()) > maior)
                {
                    maior = int.Parse(listCont.Items[i].ToString());

                    nomeMaior = nomes.Items[i].ToString();

                }

            }

                rbxResult.Text = $"Maior nome: ' {nomeMaior} ' repetido {maior} vezes \n" +
                                 $"Menor nome: ' {nomeMenor} ' repetido {menor} vezes";
        

        }

        public void button1_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text.ToLower();

            int ind = 0;

            if(txtNome.Text!="")
            {
                if (!nomes.Items.Contains(nome))
                {
                    nomes.Items.Add(nome);
                    listCont.Items.Add("1");

                    lbxNomes.Items.Clear();

                    for (int i = 0; i < nomes.Items.Count; i++)
                        lbxNomes.Items.Add(nomes.Items[i] + " (" + listCont.Items[i].ToString() + ")");
                }
                else
                {
                    ind = nomes.Items.IndexOf(nome);

                    listCont.Items[ind] = $"{int.Parse(listCont.Items[ind].ToString()) + 1}";

                    lbxNomes.Items.Clear();

                    for (int i = 0; i < nomes.Items.Count; i++)
                        lbxNomes.Items.Add(nomes.Items[i] + " (" + listCont.Items[i].ToString() + ")");
                }

                
                verificar();
            }
           
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }
    }
}
