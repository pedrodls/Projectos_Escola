﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int calcularIdade()
        {
            int dataActual = int.Parse(DateTime.Now.ToString("yyyyMMdd"));

            int dataNasc = int.Parse(dtpData.Value.ToString("yyyyMMdd"));

            int idade = ((dataActual - dataNasc) / 10000);

            return idade;
        }
        private int calcularDias()
        {
            DateTime dataActual = DateTime.Now;

            int idadeDias = int.Parse(dataActual.Subtract(dtpData.Value).Days.ToString());

            return idadeDias;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Calcular_Click(object sender, EventArgs e)
        {

            lbxResultado.Items.Add("Idade em Anos: "+calcularIdade() + " anos");
            lbxResultado.Items.Add("Idade em Meses: " + ((calcularDias()*12)/366) + " meses");
            lbxResultado.Items.Add("Idade em Semanas: " + (((calcularDias() * 12) / 366)*4) + " semanas");
            lbxResultado.Items.Add("Idade em Dias: " + calcularDias()+" dias");
            lbxResultado.Items.Add("------------------------------------");

        }

        private void dtpData_onValueChanged(object sender, EventArgs e)
        {
        }
    }
}
