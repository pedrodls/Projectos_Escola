﻿namespace _1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.Calcular = new ns1.BunifuThinButton2();
            this.lbxResultado = new System.Windows.Forms.ListBox();
            this.dtpData = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Insira a sua data de nascimento";
            // 
            // Calcular
            // 
            this.Calcular.ActiveBorderThickness = 1;
            this.Calcular.ActiveCornerRadius = 20;
            this.Calcular.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.Calcular.ActiveForecolor = System.Drawing.Color.White;
            this.Calcular.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.Calcular.BackColor = System.Drawing.SystemColors.Control;
            this.Calcular.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Calcular.BackgroundImage")));
            this.Calcular.ButtonText = "Calcular Idade";
            this.Calcular.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Calcular.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcular.ForeColor = System.Drawing.Color.SeaGreen;
            this.Calcular.IdleBorderThickness = 1;
            this.Calcular.IdleCornerRadius = 20;
            this.Calcular.IdleFillColor = System.Drawing.Color.White;
            this.Calcular.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.Calcular.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.Calcular.Location = new System.Drawing.Point(69, 108);
            this.Calcular.Margin = new System.Windows.Forms.Padding(5);
            this.Calcular.Name = "Calcular";
            this.Calcular.Size = new System.Drawing.Size(181, 41);
            this.Calcular.TabIndex = 4;
            this.Calcular.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Calcular.Click += new System.EventHandler(this.Calcular_Click);
            // 
            // lbxResultado
            // 
            this.lbxResultado.FormattingEnabled = true;
            this.lbxResultado.Location = new System.Drawing.Point(17, 171);
            this.lbxResultado.Name = "lbxResultado";
            this.lbxResultado.Size = new System.Drawing.Size(282, 160);
            this.lbxResultado.TabIndex = 5;
            // 
            // dtpData
            // 
            this.dtpData.CustomFormat = "";
            this.dtpData.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpData.Location = new System.Drawing.Point(43, 75);
            this.dtpData.MaxDate = new System.DateTime(2020, 12, 31, 0, 0, 0, 0);
            this.dtpData.Name = "dtpData";
            this.dtpData.Size = new System.Drawing.Size(229, 20);
            this.dtpData.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 353);
            this.Controls.Add(this.dtpData);
            this.Controls.Add(this.lbxResultado);
            this.Controls.Add(this.Calcular);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private ns1.BunifuThinButton2 Calcular;
        private System.Windows.Forms.ListBox lbxResultado;
        private System.Windows.Forms.DateTimePicker dtpData;
    }
}

