﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _13
{
    public partial class Form1 : Form
    {
        Random aleatorio = new Random();

        string[] pin;

        string[] pinEncr;

        string pinCerto = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            gerarPin();

            encriptarPin();

        }

        private void gerarPin()
        {
            button2.Enabled = false; 

            lblPin.Text = "";

            pin = new string[4];
            
            pinEncr = new string[4];

           

        }

        private void encriptarPin()
        {
            for (int i = 0; i < 4; i++)
                pin[i] = aleatorio.Next(0, 4) + "";

            for (int i = 0; i < 4; i++)
            {
                int r = aleatorio.Next(0, 4);

                pinEncr[i] = "?";
            }

            for (int i = 0; i < 2; i++)
            {
                int x = aleatorio.Next(0, 4) ;
                int y = aleatorio.Next(0, 3) ;

                pinEncr[x] = pin[y];
            }

            for (int i = 0; i < 4; i++)
            {
                lblPin.Text += pinEncr[i]+"";
            }
        }

        private void verificar()
        {
            if (textBox1.Text == pinCerto)
                MessageBox.Show($"Acertou {textBox1.Text} == {pinCerto}");
            else
            {
                gerarPin();

                encriptarPin();

                tentativas.Text = (int.Parse(tentativas.Text) + 1) + "";
            }

            if (int.Parse(tentativas.Text) == 3)
            {
                MessageBox.Show($"Acabaram as tentativas PIN certo : {pinCerto}");

                textBox1.Enabled = false;

                button1.Enabled = false;

                button2.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pinCerto = "";

            for (int i = 0; i < 4; i++)
                 pinCerto += pin[i];

            verificar();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            tentativas.Text = "0";

            textBox1.Enabled = true;

            button1.Enabled = true;

            button2.Enabled = false;

            gerarPin();

            encriptarPin();
        }
    }
}
