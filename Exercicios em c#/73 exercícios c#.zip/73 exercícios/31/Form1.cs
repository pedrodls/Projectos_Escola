﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _31
{
    public partial class Form1 : Form
    {
        Random a = new Random();

        int maior = 0, menor = 0;

        int la=0, ca=0, lb=0, cb=0;

        bool logico = true;

        int[,] mat = new int[4, 4];

        

        public Form1()
        {
            InitializeComponent();
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {

           
        }
        private void Encontrar_Click(object sender, EventArgs e)
        {
            DGV1.Rows.Add(4);

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    mat[i, j] = a.Next(1, 50);

                    if (i == 0 && j == 0)
                        menor = mat[i, j];

                    if (mat[i, j] > maior)
                    {
                        maior = mat[i, j];
                        la = i; ca = j;
                    }

                    if (mat[i, j] < menor)
                    {
                        menor = mat[i, j];
                        lb = i; cb = j;
                    }
                }
            }

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    DGV1.Rows[i].Cells[j].Value = mat[i, j];

                }
            }

        }
    }
}
