﻿namespace _31
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Encontrar = new System.Windows.Forms.Button();
            this.DGV1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.DGV1)).BeginInit();
            this.SuspendLayout();
            // 
            // Encontrar
            // 
            this.Encontrar.Location = new System.Drawing.Point(69, 187);
            this.Encontrar.Name = "Encontrar";
            this.Encontrar.Size = new System.Drawing.Size(180, 23);
            this.Encontrar.TabIndex = 0;
            this.Encontrar.Text = "Encontrar o menor e o maior";
            this.Encontrar.UseVisualStyleBackColor = true;
            this.Encontrar.Click += new System.EventHandler(this.Encontrar_Click);
            // 
            // DGV1
            // 
            this.DGV1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV1.Location = new System.Drawing.Point(12, 12);
            this.DGV1.Name = "DGV1";
            this.DGV1.Size = new System.Drawing.Size(303, 150);
            this.DGV1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 241);
            this.Controls.Add(this.DGV1);
            this.Controls.Add(this.Encontrar);
            this.Name = "Form1";
            this.Text = "Matriz e DataGriedView";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Encontrar;
        private System.Windows.Forms.DataGridView DGV1;
    }
}

