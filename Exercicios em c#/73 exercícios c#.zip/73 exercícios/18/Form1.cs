﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _18
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnContar_Click(object sender, EventArgs e)
        {
                txtResult.Text = ""; ListBox lbxVrf = new ListBox();

                int cont = 0; string[] vetNum = txtNum.Text.Split(',');

                int[] vetCont = new int[txtNum.TextLength];

                for (int i = 0; i < vetNum.Length; i++)
                {

                    for (int j = 0; j < vetNum.Length; j++)
                        if (vetNum[i] == vetNum[j])
                            cont++;

                if (!lbxVrf.Items.Contains(vetNum[i]))
                {
                    lbxVrf.Items.Add(vetNum[i]);

                    vetCont[i] = cont;
                }

                    cont = 0;
                }

                int maior = 0;

                string max = "";

                for (int i = 0; i < vetNum.Length; i++) {

                   
                    if (vetCont[i] > maior)
                    {
                        maior = vetCont[i];
                        max = vetNum[i];
                    }
                    
                }

                for (int i = 0; i < vetCont.Length; i++)
                    if (vetCont[i] > 1)
                        cont++;



                txtResult.Text = $"Na sequencia de numeros inseridos, apareceram {cont} vezes numeros repetidos, e a maior sequência de números consecutivos é do número {max} que apareceu {maior} vezes." ;
            
        }

        private void txtFrase_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar) || char.IsWhiteSpace(e.KeyChar) || e.KeyChar == ','))
            {

                if (e.KeyChar == '.')
                    e.KeyChar = ',';

                e.Handled = true;

            }

            if (txtNum.TextLength == 0 && e.KeyChar==',')
                e.Handled = true;

            if(txtNum.TextLength>0)
                if (txtNum.Text[txtNum.TextLength-1] == ',' && e.KeyChar == ',')
                    e.Handled = true;

            //if (!(txtNum.Text[0]==' '&& e.KeyChar==','))
            //   e.Handled=true;
        }
    }
}
