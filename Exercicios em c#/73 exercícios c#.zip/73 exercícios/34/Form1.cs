﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _34
{
    public partial class Form1 : Form
    {
        string[] meses = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
        string[] mesesExt = { "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" };

        public Form1()
        {
            InitializeComponent();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            string[] frase = txtInser.Text.Split(' ');

            for (int i = 0; i < frase.Length; i++) {
                for (int j = 0; j < 12; j++)
                    if (frase[i].Substring(1) == mesesExt[j].Substring(1))
                    {
                        frase[i] = "";
                        frase[i] = meses[j];

                        break;
                    }
            }

            txtResult.Text = "";

            for (int i = 0; i < frase.Length; i++)
                txtResult.Text += frase[i] + " ";
        }
    }
}
