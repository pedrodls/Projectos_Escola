﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbxValsPrc_MouseDown(object sender, MouseEventArgs e)
        {
            lbxPar.DoDragDrop(lbxValsPrc.SelectedItem.ToString(), DragDropEffects.Copy);
        }

        private void lbxPar_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }

        private void lbxPar_DragDrop(object sender, DragEventArgs e)
        {
            int valor = int.Parse(e.Data.GetData(DataFormats.Text).ToString());

            if (valor % 2 == 0)
            {
                lbxPar.Items.Add(valor);
                lbxValsPrc.Items.Remove(valor);
            }
            else MessageBox.Show("Esta, Apenas recebe números Pares! ");
        }

        private void lbxImpar_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }

        private void lbxImpar_DragDrop(object sender, DragEventArgs e)
        {
            int valor = int.Parse(e.Data.GetData(DataFormats.Text).ToString());

            if (valor % 2 != 0)
            {
                lbxImpar.Items.Add(valor);
                lbxValsPrc.Items.Remove(valor);
            }
            else MessageBox.Show("Esta, Apenas recebe números Impares! ");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random a = new Random();

            for (int i = 0; i <= 9; i++)
                lbxValsPrc.Items.Add(a.Next(1, 100));

            lbxValsPrc.AllowDrop = true;
            lbxPar.AllowDrop = true;
            lbxImpar.AllowDrop = true;
        }
    }
}
