﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace _15
{
    public partial class Form1 : Form
    {
        string pos = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pos += "";
        }

        private void iniciar()
        {
            string[] numRom = { "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM", "M", "MM", "MMM" };

            string[] numCard = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "200", "300", "400", "500", "600", "700", "800", "900", "1000", "2000", "3000", "4000", "5000", "6000", "7000", "8000", "9000" };

            convertRomano(numCard, numRom);

        }

        private string convertExtensao()
        {

            return convert_number_to_words(long.Parse(txtNum.Text));

        }

        public string convert_number_to_words(long number)
        {
            var hyphen = "-";
            var conjunction = " e ";
            var separator = ", ";
            var negative = "menos ";
            var dec = "virgula ";

            List<Dic> dictionary = new List<Dic>(){
        new Dic(0,"zero"),
        new Dic(1                   ,"um"),
        new Dic(2                   ,"dois"),
        new Dic(3                   ,"três"),
        new Dic(4                   ,"quatro"),
        new Dic(5                   ,"cinco"),
        new Dic(6                   ,"seis"),
        new Dic(7                   ,"sete"),
        new Dic(8                   ,"oito"),
        new Dic(9                   ,"nove"),
        new Dic(10                  ,"dez"),
        new Dic(11                  ,"onze"),
        new Dic(12                  ,"doze"),
        new Dic(13                  ,"treze"),
        new Dic(14                  ,"quatorze"),
        new Dic(15                  ,"quinze"),
        new Dic(16                  ,"dezesseis"),
        new Dic(17                  ,"dezessete"),
        new Dic(18                  ,"dezoito"),
        new Dic(19                  ,"dezenove"),
        new Dic(20                  ,"vinte"),
        new Dic(30                  ,"trinta"),
        new Dic(40                  ,"quarenta"),
        new Dic(50                  ,"cinquenta"),
        new Dic(60                  ,"sessenta"),
        new Dic(70                  ,"setenta"),
        new Dic(80                  ,"oitenta"),
        new Dic(90                  ,"noventa"),
        new Dic(100                 ,"cento"),
        new Dic(200                 ,"duzentos"),
        new Dic(300                 ,"trezentos"),
        new Dic(400                 ,"quatrocentos"),
        new Dic(500                 ,"quinhentos"),
        new Dic(600                 ,"seiscentos"),
        new Dic(700                 ,"setecentos"),
        new Dic(800                 ,"oitocentos"),
        new Dic(900                 ,"novecentos"),
        new Dic(1000                ,"mil" ),
        new Dic(1000000             ,"milhão"),//, 'milhões'),
        new Dic(1000000000          ,"bilhão"),// 'bilhões'),
        new Dic(1000000000000       ,"trilhão"),// 'trilhões'),
        new Dic(1000000000000000    ,"quatrilhão"),//', 'quatrilhões'),
        new Dic(1000000000000000000 ,"quinquilhão")//', 'quinquilhões')
        };

            if (number < 0)
            {
                return negative + convert_number_to_words(Math.Abs(number));
            }

            string final = null;

            long newNumber = 0, fraction = 0;
            //Verificar se é um numero fracionario
            if (number.ToString().Contains("."))
            {
                newNumber = int.Parse(number.ToString().Split('.')[0]);
                fraction = int.Parse(number.ToString().Split('.')[1]);
            }
            else
            {
                newNumber = number;
            }
            if (newNumber < 21) {
                final = dictionary.Find(r => r.Id == newNumber).Value;
            }
            else if (newNumber < 100) {
                int tens = ((int)newNumber / 10) * 10;
                long units = newNumber % 10;
                final = dictionary.Find(r => r.Id == tens).Value;
                if (units != 0)
                    final += conjunction + dictionary.Find(r => r.Id == units).Value;
            }
            else if (newNumber < 1000) {
                decimal hundreds = Math.Floor((decimal)(newNumber / 100)) * 100;
                long remainder = newNumber % 100;
                final = dictionary.Find(r => r.Id == hundreds).Value;
                if (remainder != 0)
                    final += conjunction + convert_number_to_words(remainder);
            }
            else { 
                    long baseUnit = (long)Math.Pow(1000, (double)Math.Floor((decimal)Math.Log((double)newNumber, (double)1000)));
                    int numBaseUnits = (int)(newNumber / baseUnit);
                    long remainder = number % baseUnit;
                if (baseUnit == 1000)
                    final = convert_number_to_words(numBaseUnits) + ' ' + dictionary.Find(r => r.Id == 1000).Value;
                else if (numBaseUnits == 1)
                    final = convert_number_to_words(numBaseUnits) + ' ' + dictionary.Find(r => r.Id == baseUnit).Value;
                else
                    final = convert_number_to_words(numBaseUnits) + ' '+ dictionary.Find(r => r.Id == baseUnit).Value.Replace("ão", "ões");
                    if (remainder != 0)
                    {
                        final += remainder < 100 ? conjunction : separator;
                        final += convert_number_to_words(remainder);
                    }
                    
            }
            if (fraction != 0)
            {
                final += dec;
                var words = new List<string>();

                foreach (var num in fraction.ToString().ToCharArray())
                {
                    words.Add(dictionary.Find(r => r.Id == (long)num).Value);
                }
                final += string.Join(" ", words.ToArray());
            }


            return final;
        }

        private void convertRomano(string[] numCard, string[] numRom)
        {
            string[] numero = new string[txtNum.TextLength];
            string aux = "";

            for (int i = 0; i < numero.Length; i++)
            {
                aux = txtNum.Text[i] + "";

                for (int j = i; j < numero.Length - 1; j++)
                    aux += 0;

                numero[i] = aux;
            }

            if (rbxRom.Checked)
            {
                for (int i = 0; i < numero.Length; i++)
                {
                    for (int j = 0; j < numCard.Length; j++)
                        if (numero[i] == numCard[j])
                            lblResultado.Text += numRom[j];

                }
            }


        }

        private void txtNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;

        }

        private void rbxRom_CheckedChanged(object sender, EventArgs e)
        {
            lblResultado.Text = "";
            iniciar();
        }

        private void txtNum_TextChanged(object sender, EventArgs e)
        {

            lblResultado.Text = "";

            rbxExt.Checked = false;

            rbxRom.Checked = false;

            if (txtNum.TextLength > 0)
                rbxExt.Enabled = true;
            else
                rbxExt.Enabled = false;

            if (txtNum.TextLength > 0 && txtNum.TextLength <= 4 && int.Parse(txtNum.Text) < 4000)
            {
                rbxRom.Enabled = true;
                lblControl.Text = "";
            }
            else
            {
                rbxRom.Enabled = false;
                lblControl.Text = "Número entre 0 e 3999 Para \n conversão romana.";
            }

        }

        private void rbxExt_CheckedChanged(object sender, EventArgs e)
        {
            lblResultado.Text = "";
            lblResultado.Text = convertExtensao();

        }
    }

    public class Dic
    {
        public Dic(long Id, String Value)
        {
            this.Id = Id;
            this.Value = Value;
        }
        public long Id { get; set; }
        public String Value { get; set; }
    }
}
