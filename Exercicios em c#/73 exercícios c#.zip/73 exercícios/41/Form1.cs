﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _41
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool abreviar(string nome)
        {
            string inabreviados = "DedeDadaDosdosDasdas";

            if (inabreviados.Contains(nome))
                return true;

            return false;
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {


            if (NomeCompleto.TextLength < 6)
                MessageBox.Show("[ Nome demasiado curto ]");
            else
            {
                string[] nome = NomeCompleto.Text.Split(' ');

                string aux;

                if (abreviar(nome[nome.Length - 2]) == true)
                {
                    aux = nome[nome.Length - 2] + " " + nome[nome.Length - 1] + ", ";

                    lblResultado.Text = aux;

                    for (int i = 0; i < nome.Length - 2; i++)
                        lblResultado.Text += nome[i] + " ";
                }
                else
                {
                    aux = nome[nome.Length - 1] + ", ";

                    lblResultado.Text = aux;

                    for (int i = 0; i < nome.Length - 1; i++)
                        lblResultado.Text += nome[i] + " ";
                }
            }
        }
    }
}
