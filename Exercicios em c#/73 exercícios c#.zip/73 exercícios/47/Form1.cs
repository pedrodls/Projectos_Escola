﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _47
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void alternativa()
        {
            int col = txtNome.TextLength / 2;
            int lin = col;

            int cont = 0;

            string[,] nome = new string[lin, col];

            for (int i = 0; i < lin; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    nome[i, j] = "[\t" + txtNome.Text[cont] + "\t] ";

                    cont++;

                    if (cont == txtNome.TextLength)
                        break;
                }

                if (cont == txtNome.TextLength)
                    break;
            }

            for (int i = 0; i < lin; i++)
            {
                for (int j = 0; j < col; j++)
                    rtxResult.Text += nome[i, j];

            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string[,] mat = new string[8, 8];
            int tam = txtNome.TextLength;

            //Incializar matriz com ponto(.)//
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                    mat[i, j] = "";
            }


            if (tam < 64) {

                int cont = 0;

                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        mat[i, j] = "[\t" + txtNome.Text[cont] + "\t] ";

                        cont++;

                        if (cont == txtNome.TextLength)
                            break;
                    }

                    if (cont == txtNome.TextLength)
                        break;
                }

                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                        rtxResult.Text += mat[i, j];

                }


            } else alternativa();


        }
        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (txtNome.TextLength > 0)
                if (txtNome.Text[txtNome.TextLength - 1] == ' ')
                    e.KeyChar = ch.ToString().ToUpper()[0];

            if (txtNome.TextLength == 0)
                e.KeyChar = ch.ToString().ToUpper()[0];
        }
    }
}
