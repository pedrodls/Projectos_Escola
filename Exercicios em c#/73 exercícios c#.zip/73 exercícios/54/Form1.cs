﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _54
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void numLinhas()
        {
            rbxResultado.Text = "Total de linhas: " + rbxTexto.Lines.Length+ " \n ----------------- \n ";
        }

        int linha = 0;

        private void qtdLetra()
        {

            linha = int.Parse(rbxLinha.Text) - 1; 

            string abc2 = new string(rbxTexto.Lines[linha].Where(c=> char.IsLetter(c)).ToArray());

            int qtd = abc2.ToCharArray().Length;

            if (linha < 0)
                linha = 0;

            
            if(qtd>0)
                rbxResultado.Text += $"Total de letras na linha {linha+1}: {qtd} \n ----------------- \n  ";
            else
                rbxResultado.Text += $"Total de letras na linha {linha+1}: {0} \n ----------------- \n  ";

        }

        private void apagarEspLin()
        {
            string aux = "";

            for (int i = 0; i < rbxTexto.Lines[linha].Length; i++)
                if (rbxTexto.Lines[linha][i] != ' ')
                    aux += rbxTexto.Lines[linha][i];

            string aux2 = "";

            int cont = 0;

            for (int i=0; i<aux.Length; i++)
            {
                aux2 += aux[i];
                cont++;

                if (cont == 5)
                {
                    aux2 += " ";
                    cont = 0;
                }

            }

            rbxResultado.Text += $"Linha {linha+1} sem espaço: ' {aux} ', agrupado em 5: ' {aux2} ' \n \n----------------- \n ";

            trocarLetras(aux.ToCharArray());
        }

        private void trocarLetras(char[] aux)
        {
            int letra; int cont = 0;

            string str = "";

            for (int i = 0; i < aux.Length; i++)
            {
                if(i==0)
                    letra = ((int)aux[i]) + i + 2;
                else
                    letra = ((int)aux[i]) + i + 1;

                aux[i] = (char)letra;

                cont++;

                
                if (cont == 5)
                    break;
            }
            for (int i = 0; i < aux.Length; i++)
                str += aux[i];

            rbxResultado.Text += $"Linha {linha + 1} sem espaço e criptografado: ' {str} ' \n ----------------- \n ";

        }

        private void fraseComParagrafos()
        {
            rbxtextoNovo.Text = "";

            

            for (int j = 0; j < rbxTexto.TextLength; j++)
            {
                if (rbxTexto.Text[j]=='.')
                    rbxtextoNovo.Text += ".\n \n";
                else
                    rbxtextoNovo.Text += rbxTexto.Text[j];
            }

        }

        private void rbxLinha_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void btnRet_Click(object sender, EventArgs e)
        {
            //try 
            //{
                numLinhas();
                qtdLetra();
                apagarEspLin();
                fraseComParagrafos();

            //}catch(Exception ex)
            //{
            //    MessageBox.Show($"Erro: {ex.Message}", "Verifique os campos");
            //}

        }
    }
}
