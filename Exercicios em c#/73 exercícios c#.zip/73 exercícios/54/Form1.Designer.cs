﻿namespace _54
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnRet = new System.Windows.Forms.Button();
            this.rbxTexto = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rbxResultado = new System.Windows.Forms.RichTextBox();
            this.rbxLinha = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.rbxtextoNovo = new System.Windows.Forms.RichTextBox();
            this.labe = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(123, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Texto:";
            // 
            // btnRet
            // 
            this.btnRet.FlatAppearance.BorderColor = System.Drawing.Color.Maroon;
            this.btnRet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRet.Location = new System.Drawing.Point(382, 219);
            this.btnRet.Name = "btnRet";
            this.btnRet.Size = new System.Drawing.Size(94, 31);
            this.btnRet.TabIndex = 3;
            this.btnRet.Text = "Resultado";
            this.btnRet.UseVisualStyleBackColor = true;
            this.btnRet.Click += new System.EventHandler(this.btnRet_Click);
            // 
            // rbxTexto
            // 
            this.rbxTexto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rbxTexto.Location = new System.Drawing.Point(177, 41);
            this.rbxTexto.Name = "rbxTexto";
            this.rbxTexto.Size = new System.Drawing.Size(499, 93);
            this.rbxTexto.TabIndex = 0;
            this.rbxTexto.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 282);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 24);
            this.label2.TabIndex = 7;
            this.label2.Text = "Saída:";
            // 
            // rbxResultado
            // 
            this.rbxResultado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rbxResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbxResultado.Location = new System.Drawing.Point(27, 308);
            this.rbxResultado.Name = "rbxResultado";
            this.rbxResultado.Size = new System.Drawing.Size(316, 121);
            this.rbxResultado.TabIndex = 8;
            this.rbxResultado.Text = "";
            // 
            // rbxLinha
            // 
            this.rbxLinha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rbxLinha.Location = new System.Drawing.Point(177, 172);
            this.rbxLinha.Name = "rbxLinha";
            this.rbxLinha.Size = new System.Drawing.Size(499, 30);
            this.rbxLinha.TabIndex = 9;
            this.rbxLinha.Text = "";
            this.rbxLinha.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rbxLinha_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(124, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(164, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Trabalhar com a linha:";
            // 
            // rbxtextoNovo
            // 
            this.rbxtextoNovo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rbxtextoNovo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbxtextoNovo.Location = new System.Drawing.Point(382, 308);
            this.rbxtextoNovo.Name = "rbxtextoNovo";
            this.rbxtextoNovo.Size = new System.Drawing.Size(316, 121);
            this.rbxtextoNovo.TabIndex = 11;
            this.rbxtextoNovo.Text = "";
            // 
            // labe
            // 
            this.labe.AutoSize = true;
            this.labe.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labe.Location = new System.Drawing.Point(378, 281);
            this.labe.Name = "labe";
            this.labe.Size = new System.Drawing.Size(259, 24);
            this.labe.TabIndex = 12;
            this.labe.Text = "Texto com Parágrafos postos:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 450);
            this.Controls.Add(this.labe);
            this.Controls.Add(this.rbxtextoNovo);
            this.Controls.Add(this.rbxLinha);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rbxResultado);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rbxTexto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRet);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "Trabalhando com Richbox";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRet;
        private System.Windows.Forms.RichTextBox rbxTexto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox rbxResultado;
        private System.Windows.Forms.RichTextBox rbxLinha;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox rbxtextoNovo;
        private System.Windows.Forms.Label labe;
    }
}

