﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double rad = double.Parse(txtRad.Text);
            double ind = int.Parse(txtInd.Text);

            txtRes.Text = (Math.Pow(rad, (1/ind))).ToString();
        }
    }
}
