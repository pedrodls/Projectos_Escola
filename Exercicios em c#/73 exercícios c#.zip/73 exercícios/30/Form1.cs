﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _30
{
    public partial class Form1 : Form
    {
        int index=-1;
        int numero = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            numero = int.Parse(textBox1.Text);

            //foreach (object bt in Controls)
            //    (bt as Button).Text = ".";

            button16.Text = ".";
            timer1.Enabled = true;
            timer1.Interval = 1000;

        }

        

        private void timer1_Tick(object sender, EventArgs e)
        {

            index++;

            for (int i=0; i< 4; i++)
            {
                if (index == 0)
                {
                    button1.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 1)
                {
                    button1.Text = "[  ]";

                    button2.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 2)
                {
                    button2.Text = "[  ]";

                    button3.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 3)
                {
                    button3.Text = "[  ]";

                    button4.Text = $"[ {numero} ]";

                    break;
                }
                if (index == 4)
                {
                    button4.Text = "[  ]";

                    button5.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 5)
                {
                    button5.Text = "[  ]";

                    button6.Text = $"[ {numero} ]";                    
                    
                    break;       
                }

                if (index == 6)
                {
                    button6.Text = "[  ]";

                    button7.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 7)
                {
                    button7.Text = "[  ]";

                    button8.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 8)
                {
                    button8.Text = "[  ]";

                    button9.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 9)
                {
                    button9.Text = "[  ]";

                    button10.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 10)
                {
                    button10.Text = "[  ]";

                    button11.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 11)
                {
                    button11.Text = "[  ]";

                    button12.Text = $"[ {numero} ]";

                    break;
                }
                if (index == 12)
                {
                    button12.Text = "[  ]";

                    button13.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 13)
                {
                    button13.Text = "[  ]";

                    button14.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 14)
                {
                    button14.Text = "[  ]";

                    button15.Text = $"[ {numero} ]";

                    break;
                }

                if (index == 15)
                {
                    button15.Text = "[  ]";

                    button16.Text = $"[ cheguei ]";

                    break;
                }

                if (index == 16)
                {
                    index = -1;
                    
                    button17.Text = "Seguinte";
                    timer1.Enabled = false;
                }

            }           
        }
    }
}
