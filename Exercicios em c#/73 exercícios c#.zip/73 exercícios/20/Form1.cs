﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void txtTela_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar))) {
                e.Handled = true;
            }
            
            if (txtTela.TextLength - 1 > 1 )
             {
                if (e.KeyChar == txtTela.Text[txtTela.TextLength - 1] || e.KeyChar == txtTela.Text[txtTela.TextLength - 2])
                {
                    int valor = int.Parse(e.KeyChar.ToString());

                    if (valor % 2 != 0)
                    {
                        valor += 1;

                        e.KeyChar = valor.ToString()[0];

                    }
                }
            }

        }
    }
}
