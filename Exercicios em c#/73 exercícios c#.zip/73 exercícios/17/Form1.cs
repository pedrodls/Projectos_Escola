﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int comeco = 0;

            int fim = richTextBox1.Text.LastIndexOf(textBox2.Text);

            richTextBox1.SelectAll();

            richTextBox1.SelectionBackColor = Color.White;

            while (comeco < fim)
            {
                richTextBox1.Find(textBox2.Text, comeco, richTextBox1.TextLength, RichTextBoxFinds.MatchCase);

                richTextBox1.SelectionBackColor = Color.Yellow;

                comeco = richTextBox1.Text.IndexOf(textBox2.Text, comeco) + 1;
            }

        }
    }
}
