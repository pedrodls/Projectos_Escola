﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _48
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConverter_Click(object sender, EventArgs e)
        {
            bool verificar = false;

            string[] numCard = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "30", "40", "50", "60", "70", "80", "90", "100", "200", "300", "400", "500", "600", "700", "800", "900", "1000", "2000", "3000", "4000", "5000", "6000", "7000", "8000", "9000" };

            string[] numExt = {"um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez", "onze", "doze", "treze", "catorze", "quinze", "dezaseis", "dezasete", "dezoito", "dezanove", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos", "oitocentos", "novecentos", "mil", "dois-mil", "três-mil", "quatro-mil", "cinco-mil", "seis-mil", "sete-mil", "oito-mil", "nove-mil" };

            //Recebendo e convertendo o valor da textBox
            string[] vetNum = txtNum.Text.Trim().ToLower().Split(' ');

            string verfc="";

            //Esvaziando os dados anteriores
            string resultado = "";

            txtResult.Text = "";

            //Buscando as palavras para serem verificadas antes do
            //Try

            for (int i = 0; i < vetNum.Length; i++)
                if (vetNum[i] != "e")
                    verfc += vetNum[i]+" ";

            string[] vetFinalExt = verfc.Trim().Split(' ');

            //Retirando 'e' na string e colocando numa variável
            //para ser tranformada em vetor de String

            for (int i = 0; i < vetFinalExt.Length; i++)
            {
                if (vetFinalExt[i] == "cem")
                    vetFinalExt[i] = "cento";

                for (int j = 0; j < numExt.Length; j++)
                    if (vetFinalExt[i] == numExt[j])
                        resultado += numCard[j] + " ";
            }

            //Resultado da string sem 'e'
            string[] r = resultado.Trim().Split(' ');

            
            if (verfc.Length == 1 && txtNum.Text == "cem")
                txtResult.Text = "100";


            //Código Principal//


            if (vetFinalExt.Length == r.Length)
            {
                try
                {

                    for (int i = 0; i < r.Length; i++)
                    {
                        if (r.Length == 1 && vetFinalExt.Length==1)
                        {
                            txtResult.Text = (r[i]);

                            verificar = true;

                            break;


                        }

                        if (r[i].Length == 2 && r[i + 1].Length == 1 && r.Length == 2)
                        {
                            txtResult.Text = (r[i].Substring(0, 1) + r[i + 1]);

                            verificar = true;

                            break;
                        }

                        if (r[i].Length == 3 && r[i + 1].Length == 2 && r.Length == 2)
                        {
                            txtResult.Text = (r[i].Substring(0, 1) + r[i + 1]);

                            verificar = true;

                            break;
                        }
                        else if (r[i].Length == 3 && r[i + 1].Length == 2 && r[i + 2].Length == 1 && r.Length == 3)
                        {
                            txtResult.Text = (r[i].Substring(0, 1) + r[i + 1].Substring(0, 1) + r[i + 2]);

                            verificar = true;

                            break;
                        }

                        if (r[i].Length == 4 && r[i + 1].Length == 1 && r.Length == 2)
                        {
                            txtResult.Text = (r[i].Substring(0, 3) + r[i + 1]);

                            verificar = true;

                            break;
                        }
                        else if (r[i].Length == 4 && r[i + 1].Length == 2 && r.Length == 2)
                        {
                            txtResult.Text = (r[i].Substring(0, 2) + r[i + 1]);

                            verificar = true;

                            break;
                        }

                        if (r[i].Length == 4 && r[i + 1].Length == 2 && r[i + 2].Length == 1 && r.Length == 3)
                        {
                            txtResult.Text = (r[i].Substring(0, 2) + r[i + 1].Substring(0, 1) + r[i + 2]);

                            verificar = true;

                            break;
                        }

                        if (r[i].Length == 4 && r[i + 1].Length == 3 && r.Length == 2)
                        {
                            txtResult.Text = (r[i].Substring(0, 1) + r[i + 1]);

                            verificar = true;

                            break;
                        }

                        if (r[i].Length == 4 && r[i + 1].Length == 3 && r[i + 2].Length == 1 && r.Length == 3)
                        {
                            txtResult.Text = (r[i].Substring(0, 1) + r[i + 1].Substring(0, 2) + r[i + 2]);

                            verificar = true;

                            break;
                        }

                        if (r[i].Length == 4 && r[i + 1].Length == 3 && r[i + 2].Length == 2 && r.Length == 3)
                        {
                            txtResult.Text = (r[i].Substring(0, 1) + r[i + 1].Substring(0, 1) + r[i + 2]);

                            verificar = true;

                            break;
                        }

                        if (r[i].Length == 4 && r[i + 1].Length == 3 && r[i + 2].Length == 2 && r[i + 3].Length == 1 && r.Length == 4)
                        {
                            txtResult.Text = (r[i].Substring(0, 1) + r[i + 1].Substring(0, 1) + r[i + 2].Substring(0, 1) + r[i + 3]);

                            verificar = true;

                            break;
                        }

                    }
                }
                catch
                {
                    MessageBox.Show("String inválida, observe a nota posta!");
                }
            }
            else
                if (verificar == false) 
                    MessageBox.Show("String inválida!!!");

        }
    }
}
