﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _37
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCript_Click(object sender, EventArgs e)
        {
            if (txtInser.Text != "" && textBox1.Text != "")
            {
                if (txtInser.Text.Contains(textBox1.Text))
                    lblResult.Text = "Palavra existente na frase";
                else
                    lblResult.Text = "Palavra inexistente na frase";

            }
            else
                MessageBox.Show("Preencha todos os campos");

        }
    }
}
