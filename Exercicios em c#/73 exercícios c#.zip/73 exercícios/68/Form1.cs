﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _68
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            string[] frase = txt1.Text.Split(' ');
            int div = 0;
            rbxRes.Text = "";

            for(int i=0; i<frase.Length; i++)
            {
               char[] palavra = frase[i].ToCharArray();

               div = palavra.Length / 2;

                for (int j = div; j < palavra.Length; j++)
                        palavra[j] = '?';

                for (int j = 0; j < palavra.Length; j++)
                    rbxRes.Text += palavra[j];

                rbxRes.Text += " ";
            }
        }
    }
}
