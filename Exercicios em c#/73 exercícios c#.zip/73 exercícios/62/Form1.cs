﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _62
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            if(txt1.TextLength>0)
            {
                string nome = "";

                for (int i = 0; i <= txt1.TextLength - 1; i++)
                {
                    for (int j = 0; j <= i; j++)
                        nome += (txt1.Text[j] + "").ToUpper();

                    rbxRes.Text += nome + "\n";
                    nome = "";

                }
            }
            else
            {
                MessageBox.Show("Verifique se os campos estão bem preenchidos");
            }
        }
    }
}
