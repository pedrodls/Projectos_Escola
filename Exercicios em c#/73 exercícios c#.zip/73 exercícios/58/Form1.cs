﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _58
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            txt2.Text = "";

            Random a = new Random();

            string[] vetDecide = new string[txt1.TextLength];

            for (int i = 0; i < txt1.TextLength; i++)
            {
                vetDecide[i] = (a.Next(0, 2)) + "";

                MessageBox.Show(vetDecide[i]+"");
            }

            for (int i = 0; i < txt1.TextLength; i++)
            {
                if (vetDecide[i] == "1")
                    txt2.Text += txt1.Text[i].ToString().ToUpper();
                else
                    txt2.Text += txt1.Text[i].ToString().ToLower();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
