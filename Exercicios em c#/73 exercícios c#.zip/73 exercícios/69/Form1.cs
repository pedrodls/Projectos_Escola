﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _69
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        char[] frase;

        private void btnRes_Click(object sender, EventArgs e)
        {
            frase = textBox1.Text.ToCharArray();

            richTextBox1.Text = "";

            for(int i=0; i<frase.Length; i++)
            {
                if (frase[i] == 'a')
                    frase[i] = '1';

                if (frase[i] == 'e')
                    frase[i] = '2';

                if (frase[i] == 'i')
                    frase[i] = '3';

                if (frase[i] == 'o')
                    frase[i] = '4';

                if (frase[i] == 'u')
                    frase[i] = '5';

                richTextBox1.Text += frase[i];
            }


        }
    }
}
