﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _51
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }

        private void btnseguinte_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength-1 > 3)
            {
                int num = int.Parse(textBox1.Text.Substring(0, 2));


                if (num >= 92 && num <= 94)
                    txtSaida.Text = "Número da Unitel";

                if (num == 22||num==21)
                    txtSaida.Text = "Número Fixo";

                if (num == 91 || num == 99)
                    txtSaida.Text = "Número da Movicel";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            txtSaida.Text = "";
        }
    }
}
