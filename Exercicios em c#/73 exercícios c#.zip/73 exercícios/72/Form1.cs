﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _72
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            try
            {
                List<int> vetCont = new List<int>();

                List<string> vetExp = new List<string>();

                string aux = "";

                for (int i = 0; i < textBox1.TextLength; i++)
                {
                    for (int j = i; j < textBox1.TextLength; j++)
                        if (textBox1.Text[i] == textBox1.Text[j])
                            aux += textBox1.Text[i];
                        else break;

                    if (!vetExp.Contains(aux))
                    {
                        vetExp.Add(aux);
                        vetCont.Add(aux.Length);
                    }

                    aux = "";

                }

                if (vetCont.IndexOf(vetCont.Max()) > 0)
                    richTextBox1.Text = "Maior: " + vetExp[vetCont.IndexOf(vetCont.Max())] + ", tamanho: " + vetCont.Max() + "\n";
            } catch 
            { MessageBox.Show("Erro, Verifique todos os campos!!!"); }
           
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }
    }
}
