﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _71
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            string[] frase = textBox1.Text.Split(' ');

            string aux = "";

            richTextBox1.Text = "";

            aux = frase[0];
            frase[0] = frase[frase.Length - 1];
            frase[frase.Length - 1] = aux;

            foreach (string str in frase)
                richTextBox1.Text += str + " ";
        }
    }
}
