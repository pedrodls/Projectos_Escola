﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace _57
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        private void txt2_KeyPress(object sender, KeyPressEventArgs e)
        {
            string str = e.KeyChar+"";

            e.KeyChar = str.Normalize(NormalizationForm.FormD)
                              .Where(ch => char.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark)
                              .ToArray()[0];
        }
    }
}
