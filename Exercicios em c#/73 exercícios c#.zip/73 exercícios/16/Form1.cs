﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _16
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string cor1 = "", cor2="";
        int cont = 0;


        private void Form1_Load(object sender, EventArgs e)
        {
            string[] cores = Enum.GetNames(typeof(KnownColor));
            
            cbx1.Items.AddRange(cores);

            cbx2.Items.AddRange(cores);
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            cont = 0;

            cor1 = cbx1.SelectedItem.ToString(); cor2 = cbx2.SelectedItem.ToString();

            lblResultado.Text = textBox1.Text;

            timer1.Enabled = true;

            timer3.Enabled = true;

        }

        private void time_1()
        {

            timer1.Tick += timer1_Tick;

            lblResultado.ForeColor = Color.FromName(cor1);

            timer1.Enabled = false;

            timer2.Enabled = true;

        }

        private void time_2()
        {
            timer1.Tick += timer1_Tick;           

            lblResultado.ForeColor = Color.FromName(cor2);

            timer1.Enabled = true;

            timer2.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            time_1();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {

            time_2();
        }
        
        private void verificar()
        {
            timer3.Tick += timer3_Tick;

            cont++;

            if (cont == 20)
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;

                MessageBox.Show(cont + " pppp  ");


            }
        }
        private void timer3_Tick(object sender, EventArgs e)
        {
            verificar();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
