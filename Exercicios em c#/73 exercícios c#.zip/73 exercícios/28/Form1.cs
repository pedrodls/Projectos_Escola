﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _28
{
    public partial class Form1 : Form
    {
        Random a = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        ListBox comparar = new ListBox();

        private void btnLerVetores_Click(object sender, EventArgs e)
        {
            lbxVet1.Items.Clear();

            checkedListBox1.Items.Clear();

            comparar.Items.Clear();

            for (int i = 0; i <= 12; i++)
                lbxVet1.Items.Add(a.Next(1, 50));

            for (int i = 0; i <= 8; i++)
                checkedListBox1.Items.Add(a.Next(1, 50));
        }


        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sair?", "SAIR", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                this.Close();
        }
         
        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (!comparar.Items.Contains(checkedListBox1.CheckedItems))
            //{
            //    comparar.Items.Add(checkedListBox1.CheckedItems);

            //    //verificar(
            //}
            //else
        }
    }
}
