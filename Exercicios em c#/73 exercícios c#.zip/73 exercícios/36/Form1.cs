﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _36
{
    public partial class Form1 : Form
    {
        string vogais = "aAeEiIoOuU";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCript_Click(object sender, EventArgs e)
        {
            lblResult.Text = "";

            for (int i = 0; i < txtInser.TextLength; i++)
            {
                if (!vogais.Contains(txtInser.Text[i]))
                    lblResult.Text+=txtInser.Text[i];
                else
                    lblResult.Text += "#";

            }

        }
    }
}
