﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _64
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            int cont = 0, letrasDif=0; 

            for (int i = 0; i <txt1.TextLength; i++)
            {
                for (int j = 0; j < txt1.TextLength; j++)
                    if ((txt1.Text[i]+"").ToLower() == (txt1.Text[j]+"").ToLower())
                    { 
                        cont++;
                    }

                if (cont == 1)
                    letrasDif++;

                cont = 0;

            }

            rbxRes.Text = $"A frase acima, tem {letrasDif} letras diferentes!";
        }
    }
}
