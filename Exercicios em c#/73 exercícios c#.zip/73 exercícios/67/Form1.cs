﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _67
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string ordenar(string vetchar)
        {
            string str = "";

            for (int i = vetchar.Length-1; i >=0; i--)
                str += vetchar[i]+"";

            return str +"";
        }

        string frasef = "";

        string[] frase= { };

        

        private void iniciar(string pal1, string pal2)
        {
            if (pal1.Length > pal2.Length)
            {
                int cont = 0;

                for (int j = 0; j < pal1.Length; j++)
                {
                    frasef += pal1[j] + "" + pal2[j];

                    cont++;

                    if (j + 1 == pal2.Length)
                    {
                        for (j = cont; j < pal1.Length; j++)
                            frasef += pal1[j];

                        break;
                    }

                }

                frasef += " ";
            }

            if (pal2.Length > pal1.Length)
            {
                int cont = 0;

                for (int j = 0; j < pal2.Length; j++)
                {
                    frasef += pal1[j] + "" + pal2[j];

                    cont++;

                    if (j + 1 == pal1.Length)
                    {
                        for (j = cont; j < pal2.Length; j++)
                            frasef += pal2[j];

                        break;
                    }

                }


                frasef += " ";
            }
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            rbxRes.Text = "";

            frasef = "";

            frase = txt1.Text.Trim().Split(' ');

            string palavra1 = "";

            string palavra2 = "";

            int cont = 0; 

            if (frase.Length % 2 ==0)
            {
                for (int i = 0; i < frase.Length - 1; i++)
                {
                    if (i == 0)
                    {
                        iniciar(frase[0], ordenar(frase[1]));

                        cont += 2;
                    }

                    if (i > 0)
                    {

                        if (cont  == frase.Length)
                            break;

                        palavra1 = frase[cont];

                        palavra2 = ordenar(frase[cont+1] + "");


                        iniciar(palavra1, palavra2);

                        cont += 2;


                    }

                }
            }

            if (frase.Length % 2 == 1)
            {
                for (int i = 0; i < frase.Length - 2; i++)
                {
                    if (i == 0)
                    {
                        iniciar(frase[0], ordenar(frase[1]));

                        cont += 2;
                    }

                    if (i > 0)
                    {

                        if (cont == frase.Length)
                            break;

                        palavra1 = frase[cont];

                        palavra2 = ordenar(frase[cont + 1] + "");


                        iniciar(palavra1, palavra2);

                        cont += 2;


                    }

                }
            }

            if (frase.Length%2!=0)
            {
                frasef += ordenar(frase[frase.Length-1]);

                rbxRes.Text = frasef;

            }
            else
                rbxRes.Text = frasef;




        }
    }
}
