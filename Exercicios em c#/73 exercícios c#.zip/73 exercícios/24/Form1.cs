﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _24
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            for (int i = 0; i <= 20; i++)
                listBox1.Items.Add("Item"+i+1);

            listBox1.AllowDrop = true;
            listBox2.AllowDrop = true;
        }

        private void listBox2_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }

        private void listBox2_DragDrop(object sender, DragEventArgs e)
        {

            listBox2.Items.Add(e.Data.GetData(DataFormats.Text));

            listBox1.Items.Remove(e.Data.GetData(DataFormats.Text));
        }

        private void listBox1_MouseDown(object sender, MouseEventArgs e)
        {
            listBox2.DoDragDrop(listBox1.SelectedItem.ToString(), DragDropEffects.Copy);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
