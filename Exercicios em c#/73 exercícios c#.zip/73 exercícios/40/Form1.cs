﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _40
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private string abreviar(string nome)
        {
            string inabreviados ="DedeDadaDosdosDasdas";

            char nomeAbreviado;

            if (inabreviados.Contains(nome))
                return " "+nome;
            else
            {
                nomeAbreviado = nome[0];
                return " " + nomeAbreviado + ". ";
            }
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            string[] nome = NomeCompleto.Text.Split(' ');

            string aux = "";

            lblResultado.Text = nome[0];

            if (NomeCompleto.TextLength < 6)
                MessageBox.Show("[ Nome demasiado curto ]");
            else {
                for (int i = 0; i < nome.Length; i++) {

                    if (i > 0 && i < nome.Length-1)
                    {
                        aux = abreviar(nome[i]);

                        lblResultado.Text += aux;
                    }
                }

                lblResultado.Text +=" "+ nome[nome.Length-1];
            }
            
        }

        private void NomeCompleto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
                e.Handled = true;


        }
    }
}
