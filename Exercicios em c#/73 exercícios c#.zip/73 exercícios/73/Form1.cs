﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _73
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConjugar_Click(object sender, EventArgs e)
        {
            txtResult.Text = "";

            string strVerbo = txtVerbo.Text.ToLower();

            string[] pronomes = { "Eu ", "Tu ", "Ele/Ela ", "Nos ", "Vós ", "Eles/Elas " };
            
            string[] terminacoes = {"o", "es", "e", "mos", "eis", "em"};

            try
            {
                if (strVerbo.Substring(strVerbo.Length - 2) == "er")
                    for (int i = 0; i < 6; i++)
                        txtResult.Text += pronomes[i] + strVerbo.Substring(0, strVerbo.Length - 2) + terminacoes[i] + "\n";
            }
            catch
            {
                MessageBox.Show("Verifique porfavor o verbo introduzido!");

            }

        }
    }
}
