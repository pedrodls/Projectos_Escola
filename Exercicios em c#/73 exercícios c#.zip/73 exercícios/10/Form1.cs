﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int index = 0;
        int[] expressaoFinal;
        string[] expressoesRes;

        private void verificaCampos()
        {
            if (rbxRaiz.Text != "" && rbxExpIncial.Text != ""&&rbxRest1.Text!="")
                btnCalcular.Enabled = true;
            else
                btnCalcular.Enabled = false;

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            index = -1;

            rbxRest2.Text = "";

            rbxResultado.Text = "";

            rbxTimerResult.Text = "";

            string[] expressaoInicial = rbxExpIncial.Text.Trim().Split(' ');

            expressaoFinal = new int[expressaoInicial.Length];

            expressoesRes = new string[expressaoInicial.Length];

            expressoesRes[0] = expressaoInicial[0]+"";

            expressaoFinal[0] = int.Parse(expressaoInicial[0]);

            for(int i=1; i<expressaoInicial.Length; i++)
            {
                expressoesRes[i] = $"(({expressaoFinal[i - 1]}) * ({int.Parse(rbxRaiz.Text)})) + ({int.Parse(expressaoInicial[i])})";
                
                expressaoFinal[i] = (expressaoFinal[i-1]*int.Parse(rbxRaiz.Text))+int.Parse(expressaoInicial[i]);

            }

            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            index++;

            if (index == expressoesRes.Length)
            {
                timer1.Enabled = false;

                rbxRest2.Text = expressaoFinal[expressaoFinal.Length - 1] * int.Parse(rbxRaiz.Text) + int.Parse(rbxRest1.Text) + "";

                rbxTimerResult.Text += $"(({expressaoFinal[expressaoFinal.Length - 1]}) * ({int.Parse(rbxRaiz.Text)}) + ({int.Parse(rbxRest1.Text)}) = {rbxRest2.Text} \n\n------";
            }
            else
            {
                rbxTimerResult.Text += (expressoesRes[index] + " = " + expressaoFinal[index]+ "\n\n");

                rbxResultado.Text += expressaoFinal[index] + " ";
            
            }

        }

        private void rbxExpIncial_TextChanged(object sender, EventArgs e)
        {
            verificaCampos();
        }

        private void rbxRest1_TextChanged(object sender, EventArgs e)
        {
            verificaCampos();
        }

        private void rbxRaiz_TextChanged(object sender, EventArgs e)
        {
            verificaCampos();
        }

        private void rbxGri_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;

            if (e.KeyChar == '-' && rbxRest1.Text == "")
                e.Handled = false;

        }

        private void rbxExpIncial_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)||e.KeyChar=='-'|| e.KeyChar==' '))
                e.Handled = true;

            if (rbxExpIncial.TextLength > 0)
                if (rbxExpIncial.Text[rbxExpIncial.TextLength - 1] == '-' && e.KeyChar == '-')
                    e.Handled = true;

            if (rbxExpIncial.TextLength > 0)
                if (rbxExpIncial.Text[rbxExpIncial.TextLength - 1] == ' ' && e.KeyChar == ' ')
                    e.Handled = true;

            if (rbxExpIncial.TextLength > 0)
                if (rbxExpIncial.Text[rbxExpIncial.TextLength - 1] != ' ' && e.KeyChar == '-')
                    e.Handled = true;

            if (rbxExpIncial.TextLength > 0)
                if (rbxExpIncial.Text[rbxExpIncial.TextLength - 1] == '-' && e.KeyChar == ' ')
                    e.Handled = true;

            if (rbxExpIncial.TextLength == 0 && e.KeyChar == ' ')
                    e.Handled = true;
        }
    }
}
