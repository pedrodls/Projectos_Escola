﻿namespace _10
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rbxRest2 = new System.Windows.Forms.RichTextBox();
            this.rbxResultado = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.rbxRest1 = new System.Windows.Forms.RichTextBox();
            this.rbxExpIncial = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rbxRaiz = new System.Windows.Forms.RichTextBox();
            this.bunifuSeparator4 = new ns1.BunifuSeparator();
            this.bunifuSeparator3 = new ns1.BunifuSeparator();
            this.bunifuSeparator2 = new ns1.BunifuSeparator();
            this.bunifuSeparator1 = new ns1.BunifuSeparator();
            this.bunifuSeparator5 = new ns1.BunifuSeparator();
            this.rbxTimerResult = new System.Windows.Forms.RichTextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Enabled = false;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(221, 307);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(96, 38);
            this.btnCalcular.TabIndex = 41;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(147, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(227, 13);
            this.label8.TabIndex = 40;
            this.label8.Text = "Coeficientes da divisão separados por espaço:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(407, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "Resto final";
            // 
            // rbxRest2
            // 
            this.rbxRest2.BackColor = System.Drawing.Color.DarkGray;
            this.rbxRest2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rbxRest2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbxRest2.Location = new System.Drawing.Point(407, 226);
            this.rbxRest2.Name = "rbxRest2";
            this.rbxRest2.Size = new System.Drawing.Size(57, 38);
            this.rbxRest2.TabIndex = 35;
            this.rbxRest2.Text = "";
            // 
            // rbxResultado
            // 
            this.rbxResultado.BackColor = System.Drawing.Color.DarkGray;
            this.rbxResultado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rbxResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbxResultado.Location = new System.Drawing.Point(142, 226);
            this.rbxResultado.Name = "rbxResultado";
            this.rbxResultado.Size = new System.Drawing.Size(240, 38);
            this.rbxResultado.TabIndex = 32;
            this.rbxResultado.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(413, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 30;
            this.label3.Text = "Resto";
            // 
            // rbxRest1
            // 
            this.rbxRest1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.rbxRest1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rbxRest1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbxRest1.Location = new System.Drawing.Point(407, 52);
            this.rbxRest1.Name = "rbxRest1";
            this.rbxRest1.Size = new System.Drawing.Size(51, 38);
            this.rbxRest1.TabIndex = 29;
            this.rbxRest1.Text = "";
            this.rbxRest1.TextChanged += new System.EventHandler(this.rbxRest1_TextChanged);
            this.rbxRest1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rbxGri_KeyPress);
            // 
            // rbxExpIncial
            // 
            this.rbxExpIncial.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.rbxExpIncial.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rbxExpIncial.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbxExpIncial.Location = new System.Drawing.Point(140, 52);
            this.rbxExpIncial.Name = "rbxExpIncial";
            this.rbxExpIncial.Size = new System.Drawing.Size(240, 38);
            this.rbxExpIncial.TabIndex = 28;
            this.rbxExpIncial.Text = "";
            this.rbxExpIncial.TextChanged += new System.EventHandler(this.rbxExpIncial_TextChanged);
            this.rbxExpIncial.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rbxExpIncial_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(140, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(240, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Coeficientes do dividendo separados por espaço:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Raiz do divisor";
            // 
            // rbxRaiz
            // 
            this.rbxRaiz.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.rbxRaiz.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rbxRaiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbxRaiz.Location = new System.Drawing.Point(55, 139);
            this.rbxRaiz.Name = "rbxRaiz";
            this.rbxRaiz.Size = new System.Drawing.Size(69, 38);
            this.rbxRaiz.TabIndex = 25;
            this.rbxRaiz.Text = "";
            this.rbxRaiz.TextChanged += new System.EventHandler(this.rbxRaiz_TextChanged);
            this.rbxRaiz.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rbxGri_KeyPress);
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator4.LineThickness = 1;
            this.bunifuSeparator4.Location = new System.Drawing.Point(386, 43);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(13, 234);
            this.bunifuSeparator4.TabIndex = 24;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = true;
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(124, 43);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(10, 234);
            this.bunifuSeparator3.TabIndex = 23;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = true;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(55, 193);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(412, 17);
            this.bunifuSeparator2.TabIndex = 22;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(55, 77);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(412, 35);
            this.bunifuSeparator1.TabIndex = 21;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // bunifuSeparator5
            // 
            this.bunifuSeparator5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator5.LineThickness = 1;
            this.bunifuSeparator5.Location = new System.Drawing.Point(141, 104);
            this.bunifuSeparator5.Name = "bunifuSeparator5";
            this.bunifuSeparator5.Size = new System.Drawing.Size(10, 86);
            this.bunifuSeparator5.TabIndex = 42;
            this.bunifuSeparator5.Transparency = 255;
            this.bunifuSeparator5.Vertical = true;
            // 
            // rbxTimerResult
            // 
            this.rbxTimerResult.BackColor = System.Drawing.Color.DarkGray;
            this.rbxTimerResult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rbxTimerResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbxTimerResult.Location = new System.Drawing.Point(156, 104);
            this.rbxTimerResult.Name = "rbxTimerResult";
            this.rbxTimerResult.Size = new System.Drawing.Size(225, 83);
            this.rbxTimerResult.TabIndex = 43;
            this.rbxTimerResult.Text = "";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 357);
            this.Controls.Add(this.rbxTimerResult);
            this.Controls.Add(this.bunifuSeparator5);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rbxRest2);
            this.Controls.Add(this.rbxResultado);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rbxRest1);
            this.Controls.Add(this.rbxExpIncial);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rbxRaiz);
            this.Controls.Add(this.bunifuSeparator4);
            this.Controls.Add(this.bunifuSeparator3);
            this.Controls.Add(this.bunifuSeparator2);
            this.Controls.Add(this.bunifuSeparator1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "Dispositivo prático de Briott Rufini";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox rbxRest2;
        private System.Windows.Forms.RichTextBox rbxResultado;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox rbxRest1;
        private System.Windows.Forms.RichTextBox rbxExpIncial;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox rbxRaiz;
        private ns1.BunifuSeparator bunifuSeparator4;
        private ns1.BunifuSeparator bunifuSeparator3;
        private ns1.BunifuSeparator bunifuSeparator2;
        private ns1.BunifuSeparator bunifuSeparator1;
        private ns1.BunifuSeparator bunifuSeparator5;
        private System.Windows.Forms.RichTextBox rbxTimerResult;
        private System.Windows.Forms.Timer timer1;
    }
}

