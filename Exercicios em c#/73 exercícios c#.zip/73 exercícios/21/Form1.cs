﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _21
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random r = new Random();

            lbxNumeros.Items.Add(r.Next(0, 9));
            lbxNumeros.Items.Add(r.Next(0, 9));
            lbxNumeros.Items.Add(r.Next(0, 9));
            lbxNumeros.Items.Add(r.Next(0, 9));
        }


        int somaPrimo = 0;

        int contValLista = 0;

        private void consecutivoIguais()
        {
            if (textBox1.Text[textBox1.TextLength - 1] == textBox1.Text[textBox1.TextLength - 2] && textBox1.Text[textBox1.TextLength - 1] == textBox1.Text[textBox1.TextLength - 3])
                MessageBox.Show("Foram inseridos 3 Nsº \n consecutivos iguais");

            textBox1.Enabled = false;
        }

        private void verificarPrimo_Impar()
        {
            
            if (primo(int.Parse(textBox1.Text[textBox1.TextLength - 1].ToString())) == true && primo(int.Parse(textBox1.Text[textBox1.TextLength - 2].ToString())) == true && (textBox1.Text[textBox1.TextLength - 3] % 2 != 0))
            {
                MessageBox.Show("Foi inserido dois números primo seguido de um \n ímpar");

                textBox1.Enabled = false;
            }

        }

        private void parImparPar()
        {
            if (textBox1.Text[textBox1.TextLength - 1] % 2 == 0 && textBox1.Text[textBox1.TextLength - 2] % 2 != 0 && textBox1.Text[textBox1.TextLength - 1] % 2 == 0)
            {
                MessageBox.Show("Foi inserido um número par seguido de um \n ímpar e depois outro par");
                
                textBox1.Enabled = false;
            }

        }

        private bool primo(int num)
        {
            int cont = 0;

            for (int i = 1; i <= num; i++)
            {
                if (num%i==0)
                    cont++;
            }

            if(cont==2)
                return true;
            else
                return false;
        }

        private void soma()
        {

            for (int i = 0; i < textBox1.TextLength; i++)
                if (primo(int.Parse(textBox1.Text[i] + "")) == true)
                    somaPrimo++;

            if (somaPrimo > 30)
            {
                MessageBox.Show("Leitura parada porque a contagem excedeu a 30!");

                textBox1.Enabled = false;
            }
        }

        private void verificarMetadeDaLista()
        {
            int cont = 0;

            for (int i = 0; i < textBox1.TextLength; i++)
                if (lbxNumeros.Items.Contains(textBox1.Text[i]))
                    cont++;

            if (cont==2)
            {
                MessageBox.Show("Leitura parada porque a contagem excedeu a metade dos valores da lista!");

                textBox1.Enabled = false;
            }
        }

        private void verificarLista()
        {
            contValLista = 0;

            for (int i = 0; i < textBox1.TextLength; i++)
                if (lbxNumeros.Items.Contains(textBox1.Text[i]))
                    contValLista++;

            if (contValLista == 8)
            {
                MessageBox.Show("Leitura parada porque a contagem dos valores da lista, foram inseridos 2 vezes!");

                textBox1.Enabled = false;
            }
        }


        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;

            
            if (textBox1.TextLength > 1)
            {
                if (textBox1.TextLength - 1 > 1)
                {

                    consecutivoIguais();

                    verificarPrimo_Impar();
                }

                soma();

                parImparPar();

                verificarMetadeDaLista();

                verificarLista();

            }
        }

        
    }
}
