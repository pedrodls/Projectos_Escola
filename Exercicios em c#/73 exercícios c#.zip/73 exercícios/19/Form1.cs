﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _19
{ 
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            ListBox lbx = new ListBox();

            Label lb = new Label();

            base.OnPaint(e);

            Rectangle rect = new Rectangle(10,10,100,200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect);

            rect.Inflate(-10, -10);

           

            for (int i=1; i<=12; i++)
            {
                for (int j = 1; j <=12; j++)
                {
                    lbx.Items.Add($"{i} x {j} = {(i) * (j)}");
                }

            }           
                for (int j = 0; j <=11; j++)
                    lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect);

            //******************************************************************************//

            Rectangle rect2 = new Rectangle(100, 10, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect2);

            rect2.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 12; j <= 23; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect2);
            //******************************************************************************//


            Rectangle rect3 = new Rectangle(200, 10, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect3);

            rect3.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 24; j <= 35; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect3);

            //******************************************************************************//


            Rectangle rect4 = new Rectangle(300, 10, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect4);

            rect4.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 36; j <= 47; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect4);
            //******************************************************************************//

            Rectangle rect5 = new Rectangle(10, 170, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect5);

            rect5.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 48; j <= 59; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect5);
            //******************************************************************************//


            Rectangle rect6 = new Rectangle(100, 170, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect6);

            rect6.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 60; j <= 71; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect6);
            //******************************************************************************//

            Rectangle rect7 = new Rectangle(200, 170, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect7);

            rect7.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 72; j <= 83; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect7);
            //******************************************************************************//

            Rectangle rect8 = new Rectangle(300, 170, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect8);

            rect8.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 84; j <= 95; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect8);
            //******************************************************************************//

            Rectangle rect9 = new Rectangle(10, 325, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect9);

            rect9.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 96; j <= 107; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect9);
            //******************************************************************************//


            Rectangle rect10 = new Rectangle(100, 325, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect10);

            rect10.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 108; j <= 119; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect10);
            //******************************************************************************//


            Rectangle rect11 = new Rectangle(200, 325, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect11);

            rect11.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 120; j <= 131; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect11);
            //******************************************************************************//


            Rectangle rect12 = new Rectangle(300, 325, 100, 200);

            e.Graphics.FillRectangle(Brushes.Transparent, rect12);

            rect12.Inflate(-10, -10);

            lb.Text = "";

            for (int j = 132; j <= 143; j++)
                lb.Text += lbx.Items[j].ToString() + "\n";

            e.Graphics.DrawString(lb.Text, this.Font, Brushes.Black, rect12);
            //******************************************************************************//

        }

    }
}
